package com.viaadvancedbrowser.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.room.Room
import com.viaadvancedbrowser.data.local.database.AppDatabase
import com.viaadvancedbrowser.data.local.datastore.SettingsDataStore
import com.viaadvancedbrowser.data.repository.BrowserRepository
import com.viaadvancedbrowser.data.repository.SettingsRepository
import com.viaadvancedbrowser.features.adblock.AdBlocker
import com.viaadvancedbrowser.features.download.DownloadManager
import com.viaadvancedbrowser.features.vpn.VPNManager
import com.viaadvancedbrowser.network.ApiClient
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "via_browser.db"
        ).fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    @Singleton
    fun provideSettingsDataStore(@ApplicationContext context: Context): SettingsDataStore {
        // expects a DataStore<Preferences> (context.appDataStore extension provided from Application)
        return SettingsDataStore(context.appDataStore)
    }

    @Provides
    @Singleton
    fun provideBrowserRepository(
        database: AppDatabase,
        settingsDataStore: SettingsDataStore,
        adBlocker: AdBlocker,
        @IoDispatcher ioDispatcher: CoroutineDispatcher
    ): BrowserRepository {
        return BrowserRepository(
            database = database,
            settingsDataStore = settingsDataStore,
            adBlocker = adBlocker,
            ioDispatcher = ioDispatcher
        )
    }

    @Provides
    @Singleton
    fun provideSettingsRepository(
        settingsDataStore: SettingsDataStore
    ): SettingsRepository {
        return SettingsRepository(settingsDataStore)
    }

    @Provides
    @Singleton
    fun provideAdBlocker(@ApplicationContext context: Context): AdBlocker {
        return AdBlocker(context)
    }

    @Provides
    @Singleton
    fun provideVPNManager(@ApplicationContext context: Context): VPNManager {
        return VPNManager(context)
    }

    @Provides
    @Singleton
    fun provideDownloadManager(@ApplicationContext context: Context): DownloadManager {
        return DownloadManager(context)
    }

    @Provides
    @Singleton
    fun provideApiClient(): ApiClient {
        return ApiClient()
    }

    @Provides
    @IoDispatcher
    fun provideIoDispatcher(): CoroutineDispatcher = Dispatchers.IO
}