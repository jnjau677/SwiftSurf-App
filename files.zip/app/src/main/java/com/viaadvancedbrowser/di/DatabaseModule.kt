package com.viaadvancedbrowser.di

import com.viaadvancedbrowser.data.local.database.AppDatabase
import com.viaadvancedbrowser.data.local.database.dao.BookmarkDao
import com.viaadvancedbrowser.data.local.database.dao.HistoryDao
import com.viaadvancedbrowser.data.local.database.dao.PasswordDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideHistoryDao(database: AppDatabase): HistoryDao {
        return database.historyDao()
    }

    @Provides
    @Singleton
    fun provideBookmarkDao(database: AppDatabase): BookmarkDao {
        return database.bookmarkDao()
    }

    @Provides
    @Singleton
    fun providePasswordDao(database: AppDatabase): PasswordDao {
        return database.passwordDao()
    }
}