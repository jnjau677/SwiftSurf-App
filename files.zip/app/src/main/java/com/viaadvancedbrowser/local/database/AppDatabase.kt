package com.viaadvancedbrowser.local.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.viaadvancedbrowser.local.database.dao.BookmarkDao
import com.viaadvancedbrowser.local.database.dao.HistoryDao
import com.viaadvancedbrowser.local.database.entity.BookmarkEntity
import com.viaadvancedbrowser.local.database.entity.HistoryEntity

@Database(entities = [HistoryEntity::class, BookmarkEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao
    abstract fun bookmarkDao(): BookmarkDao
}