package com.viaadvancedbrowser.local.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.viaadvancedbrowser.local.database.entity.BookmarkEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BookmarkDao {
    @Insert
    suspend fun insert(bookmark: BookmarkEntity)

    @Query("SELECT * FROM bookmark ORDER BY addedAt DESC")
    fun bookmarksFlow(): Flow<List<BookmarkEntity>>
}