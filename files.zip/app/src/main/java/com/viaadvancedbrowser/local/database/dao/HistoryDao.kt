package com.viaadvancedbrowser.local.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.viaadvancedbrowser.local.database.entity.HistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {
    @Insert
    suspend fun insert(history: HistoryEntity)

    @Query("SELECT * FROM history ORDER BY visitedAt DESC")
    fun historyFlow(): Flow<List<HistoryEntity>>
}