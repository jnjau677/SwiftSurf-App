package com.viaadvancedbrowser.utils

import android.webkit.WebView

fun WebView.loadUrlSafe(url: String) {
    if (url.startsWith("http")) this.loadUrl(url)
}