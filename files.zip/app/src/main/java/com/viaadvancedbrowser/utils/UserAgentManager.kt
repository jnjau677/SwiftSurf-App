package com.viaadvancedbrowser.utils

import com.viaadvancedbrowser.BuildConfig
import kotlin.random.Random

object UserAgentManager {

    // BuildConfig.DESKTOP_USER_AGENTS is expected to be an array/list defined in build.gradle or similar.
    // If you prefer to store user-agents in resources, we can change this implementation.
    private val desktopUserAgents: Array<String> =
        try {
            BuildConfig.DESKTOP_USER_AGENTS
        } catch (_: Throwable) {
            // Fallback default user agents
            arrayOf(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Safari/605.1.15"
            )
        }

    private var currentUserAgentIndex = 0

    fun getRandomDesktopUserAgent(): String {
        return desktopUserAgents[Random.nextInt(desktopUserAgents.size)]
    }

    fun getNextDesktopUserAgent(): String {
        currentUserAgentIndex = (currentUserAgentIndex + 1) % desktopUserAgents.size
        return desktopUserAgents[currentUserAgentIndex]
    }

    fun getDesktopUserAgent(index: Int): String {
        return desktopUserAgents[index % desktopUserAgents.size]
    }

    fun getAllDesktopUserAgents(): List<String> {
        return desktopUserAgents.toList()
    }

    fun isDesktopUserAgent(userAgent: String): Boolean {
        return desktopUserAgents.any { it == userAgent }
    }

    fun rotateUserAgent(): String {
        return getNextDesktopUserAgent()
    }

    fun getCurrentIndex(): Int {
        return currentUserAgentIndex
    }
}