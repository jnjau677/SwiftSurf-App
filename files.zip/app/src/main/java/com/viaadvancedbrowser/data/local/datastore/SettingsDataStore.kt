package com.viaadvancedbrowser.data.local.datastore

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsDataStore @Inject constructor(
    private val dataStore: DataStore<Preferences>
) {

    companion object {
        private val KEY_THEME = intPreferencesKey("theme")
        private val KEY_DESKTOP_MODE = booleanPreferencesKey("desktop_mode")
        private val KEY_AD_BLOCK = booleanPreferencesKey("ad_block")
        private val KEY_JAVASCRIPT = booleanPreferencesKey("javascript")
        private val KEY_HOME_PAGE = stringPreferencesKey("home_page")
        private val KEY_SEARCH_ENGINE = stringPreferencesKey("search_engine")
        private val KEY_DOWNLOAD_LOCATION = stringPreferencesKey("download_location")
        private val KEY_PRIVATE_MODE = booleanPreferencesKey("private_mode")
    }

    val currentTheme: Flow<Int> = dataStore.data
        .map { preferences -> preferences[KEY_THEME] ?: 2 }

    val desktopModeEnabled: Flow<Boolean> = dataStore.data
        .map { preferences -> preferences[KEY_DESKTOP_MODE] ?: false }

    val adBlockEnabled: Flow<Boolean> = dataStore.data
        .map { preferences -> preferences[KEY_AD_BLOCK] ?: true }

    val javaScriptEnabled: Flow<Boolean> = dataStore.data
        .map { preferences -> preferences[KEY_JAVASCRIPT] ?: true }

    val homePage: Flow<String> = dataStore.data
        .map { preferences -> preferences[KEY_HOME_PAGE] ?: "https://www.google.com" }

    val searchEngine: Flow<String> = dataStore.data
        .map { preferences -> preferences[KEY_SEARCH_ENGINE] ?: "google" }

    suspend fun setTheme(theme: Int) {
        dataStore.edit { preferences ->
            preferences[KEY_THEME] = theme
        }
    }

    suspend fun setDesktopMode(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[KEY_DESKTOP_MODE] = enabled
        }
    }

    suspend fun setAdBlockEnabled(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[KEY_AD_BLOCK] = enabled
        }
    }

    suspend fun setJavaScriptEnabled(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[KEY_JAVASCRIPT] = enabled
        }
    }

    suspend fun setHomePage(url: String) {
        dataStore.edit { preferences ->
            preferences[KEY_HOME_PAGE] = url
        }
    }

    suspend fun setSearchEngine(engine: String) {
        dataStore.edit { preferences ->
            preferences[KEY_SEARCH_ENGINE] = engine
        }
    }

    suspend fun clearAll() {
        dataStore.edit { preferences ->
            preferences.clear()
        }
    }
}