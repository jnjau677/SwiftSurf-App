package com.viaadvancedbrowser.data.repository

import android.webkit.URLUtil
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import com.viaadvancedbrowser.data.local.database.AppDatabase
import com.viaadvancedbrowser.data.local.database.entity.BookmarkEntity
import com.viaadvancedbrowser.data.local.database.entity.HistoryEntity
import com.viaadvancedbrowser.data.local.datastore.SettingsDataStore
import com.viaadvancedbrowser.features.adblock.AdBlocker
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BrowserRepository @Inject constructor(
    private val database: AppDatabase,
    private val settingsDataStore: SettingsDataStore,
    private val adBlocker: AdBlocker,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) {

    private val historyDao = database.historyDao()
    private val bookmarkDao = database.bookmarkDao()

    // Settings flows
    val isDesktopModeEnabled: Flow<Boolean> = settingsDataStore.desktopModeEnabled
    val isAdBlockEnabled: Flow<Boolean> = settingsDataStore.adBlockEnabled
    val isJavaScriptEnabled: Flow<Boolean> = settingsDataStore.javaScriptEnabled
    val currentTheme: Flow<Int> = settingsDataStore.currentTheme
    val homePage: Flow<String> = settingsDataStore.homePage

    suspend fun getHomePage(): String {
        return homePage.first()
    }

    suspend fun setDesktopMode(enabled: Boolean) {
        settingsDataStore.setDesktopMode(enabled)
    }

    suspend fun setAdBlockEnabled(enabled: Boolean) {
        settingsDataStore.setAdBlockEnabled(enabled)
    }

    suspend fun setJavaScriptEnabled(enabled: Boolean) {
        settingsDataStore.setJavaScriptEnabled(enabled)
    }

    suspend fun handleDownload(
        url: String,
        contentDisposition: String,
        mimeType: String
    ) {
        withContext(ioDispatcher) {
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            // Implement download logic here
        }
    }

    suspend fun addHistory(url: String, title: String) {
        withContext(ioDispatcher) {
            historyDao.insert(
                HistoryEntity(
                    url = url,
                    title = title,
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun getHistory(): List<HistoryEntity> {
        return withContext(ioDispatcher) {
            historyDao.getAll()
        }
    }

    suspend fun clearHistory() {
        withContext(ioDispatcher) {
            historyDao.deleteAll()
        }
    }

    suspend fun addBookmark(url: String, title: String) {
        withContext(ioDispatcher) {
            bookmarkDao.insert(
                BookmarkEntity(
                    url = url,
                    title = title,
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun getBookmarks(): List<BookmarkEntity> {
        return withContext(ioDispatcher) {
            bookmarkDao.getAll()
        }
    }

    suspend fun deleteBookmark(url: String) {
        withContext(ioDispatcher) {
            bookmarkDao.deleteByUrl(url)
        }
    }

    suspend fun getSearchUrl(query: String): String {
        val searchEngine = settingsDataStore.searchEngine.first()
        return when (searchEngine) {
            "google" -> "https://www.google.com/search?q=${query.urlEncoded()}"
            "bing" -> "https://www.bing.com/search?q=${query.urlEncoded()}"
            "duckduckgo" -> "https://duckduckgo.com/?q=${query.urlEncoded()}"
            else -> "https://www.google.com/search?q=${query.urlEncoded()}"
        }
    }

    private fun String.urlEncoded(): String {
        return java.net.URLEncoder.encode(this, "UTF-8")
    }
}