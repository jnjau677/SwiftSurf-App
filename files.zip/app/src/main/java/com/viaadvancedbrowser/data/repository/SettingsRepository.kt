package com.viaadvancedbrowser.data.repository

import com.viaadvancedbrowser.data.local.datastore.SettingsDataStore
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsRepository @Inject constructor(
    private val settingsDataStore: SettingsDataStore
) {

    val currentTheme: Flow<Int> = settingsDataStore.currentTheme
    val isDesktopModeEnabled: Flow<Boolean> = settingsDataStore.desktopModeEnabled
    val isAdBlockEnabled: Flow<Boolean> = settingsDataStore.adBlockEnabled
    val isJavaScriptEnabled: Flow<Boolean> = settingsDataStore.javaScriptEnabled
    val homePage: Flow<String> = settingsDataStore.homePage
    val searchEngine: Flow<String> = settingsDataStore.searchEngine

    suspend fun setTheme(theme: Int) {
        settingsDataStore.setTheme(theme)
    }

    suspend fun setDesktopMode(enabled: Boolean) {
        settingsDataStore.setDesktopMode(enabled)
    }

    suspend fun setAdBlockEnabled(enabled: Boolean) {
        settingsDataStore.setAdBlockEnabled(enabled)
    }

    suspend fun setJavaScriptEnabled(enabled: Boolean) {
        settingsDataStore.setJavaScriptEnabled(enabled)
    }

    suspend fun setHomePage(url: String) {
        settingsDataStore.setHomePage(url)
    }

    suspend fun setSearchEngine(engine: String) {
        settingsDataStore.setSearchEngine(engine)
    }

    suspend fun clearAllData() {
        settingsDataStore.clearAll()
    }
}