package com.viaadvancedbrowser.data.local.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.viaadvancedbrowser.data.local.database.dao.BookmarkDao
import com.viaadvancedbrowser.data.local.database.dao.HistoryDao
import com.viaadvancedbrowser.data.local.database.dao.PasswordDao
import com.viaadvancedbrowser.data.local.database.entity.BookmarkEntity
import com.viaadvancedbrowser.data.local.database.entity.HistoryEntity
import com.viaadvancedbrowser.data.local.database.entity.PasswordEntity

@Database(
    entities = [
        HistoryEntity::class,
        BookmarkEntity::class,
        PasswordEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun historyDao(): HistoryDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun passwordDao(): PasswordDao
}

class Converters {
    // Add type converters if needed
}