package com.viaadvancedbrowser.data.model

import android.graphics.Bitmap
import android.os.Parcelable
import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Entity(tableName = "tabs")
@Parcelize
data class BrowserTab(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String = "",
    val url: String = "",
    val originalUrl: String = "",
    val favicon: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val lastAccessed: Long = System.currentTimeMillis(),
    val position: Int = 0,
    val isIncognito: Boolean = false,
    val isPinned: Boolean = false,
    val isClosed: Boolean = false,
    val parentTabId: Long? = null,
    val sessionId: String = UUID.randomUUID().toString(),
    val scrollX: Int = 0,
    val scrollY: Int = 0,
    val zoomLevel: Float = 1.0f,
    val restoreState: String? = null,
    val thumbnailPath: String? = null,
    val metadata: Map<String, String> = emptyMap()
) : Parcelable {

    @Ignore
    var thumbnail: Bitmap? = null

    @Ignore
    var isSelected: Boolean = false

    @Ignore
    var isLoading: Boolean = false

    @Ignore
    var progress: Int = 0

    fun isValid(): Boolean {
        return url.isNotBlank() && !isClosed
    }

    fun isHomeTab(): Boolean {
        return url.isEmpty() || url == "about:blank" || url == "about:home"
    }

    fun getDomain(): String {
        return try {
            val uri = java.net.URI(url)
            uri.host ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    fun updateLastAccessed() = copy(lastAccessed = System.currentTimeMillis())

    fun markAsClosed() = copy(isClosed = true, lastAccessed = System.currentTimeMillis())

    fun pin() = copy(isPinned = true)

    fun unpin() = copy(isPinned = false)

    fun updateUrl(newUrl: String) = copy(
        url = newUrl,
        originalUrl = if (originalUrl.isEmpty()) newUrl else originalUrl,
        lastAccessed = System.currentTimeMillis()
    )

    fun updateTitle(newTitle: String) = copy(
        title = newTitle,
        lastAccessed = System.currentTimeMillis()
    )

    fun updateScrollPosition(x: Int, y: Int) = copy(
        scrollX = x,
        scrollY = y
    )

    fun updateZoomLevel(zoom: Float) = copy(zoomLevel = zoom)

    fun saveState(state: String) = copy(restoreState = state)

    companion object {
        fun createHomeTab(sessionId: String = UUID.randomUUID().toString()): BrowserTab {
            return BrowserTab(
                title = "New Tab",
                url = "about:blank",
                sessionId = sessionId,
                timestamp = System.currentTimeMillis(),
                lastAccessed = System.currentTimeMillis()
            )
        }

        fun createIncognitoTab(sessionId: String = UUID.randomUUID().toString()): BrowserTab {
            return BrowserTab(
                title = "Incognito Tab",
                url = "about:blank",
                isIncognito = true,
                sessionId = sessionId,
                timestamp = System.currentTimeMillis(),
                lastAccessed = System.currentTimeMillis()
            )
        }

        fun createFromUrl(
            url: String,
            title: String = "",
            parentTabId: Long? = null,
            isIncognito: Boolean = false
        ): BrowserTab {
            return BrowserTab(
                title = title.ifEmpty { "Loading..." },
                url = url,
                originalUrl = url,
                parentTabId = parentTabId,
                isIncognito = isIncognito,
                timestamp = System.currentTimeMillis(),
                lastAccessed = System.currentTimeMillis(),
                sessionId = UUID.randomUUID().toString()
            )
        }
    }
}

// Tab group/collection
@Parcelize
data class TabGroup(
    val id: Long = 0,
    val title: String,
    val color: Int,
    val tabIds: List<Long> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val isCollapsed: Boolean = false,
    val metadata: Map<String, String> = emptyMap()
) : Parcelable {

    val tabCount: Int get() = tabIds.size
    val isEmpty: Boolean get() = tabIds.isEmpty()

    fun addTab(tabId: Long): TabGroup {
        return copy(tabIds = tabIds + tabId)
    }

    fun removeTab(tabId: Long): TabGroup {
        return copy(tabIds = tabIds.filter { it != tabId })
    }

    fun containsTab(tabId: Long): Boolean {
        return tabIds.contains(tabId)
    }

    fun toggleCollapse(): TabGroup {
        return copy(isCollapsed = !isCollapsed)
    }
}

// Tab session
@Parcelize
data class TabSession(
    val id: String,
    val name: String,
    val tabs: List<BrowserTab>,
    val createdAt: Long = System.currentTimeMillis(),
    val lastRestored: Long? = null,
    val metadata: Map<String, String> = emptyMap()
) : Parcelable {

    val tabCount: Int get() = tabs.size

    fun isValid(): Boolean {
        return name.isNotBlank() && tabs.isNotEmpty()
    }

    fun updateLastRestored(): TabSession {
        return copy(lastRestored = System.currentTimeMillis())
    }

    fun filterIncognito(): TabSession {
        return copy(tabs = tabs.filter { !it.isIncognito })
    }
}

// Tab state for ViewModel
data class TabState(
    val tabs: List<BrowserTab> = emptyList(),
    val currentTabId: Long? = null,
    val tabGroups: List<TabGroup> = emptyList(),
    val selectedGroupId: Long? = null,
    val sessions: List<TabSession> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
) {
    val currentTab: BrowserTab?
        get() = tabs.find { it.id == currentTabId }

    val tabCount: Int get() = tabs.size

    val incognitoTabCount: Int get() = tabs.count { it.isIncognito }

    val normalTabCount: Int get() = tabCount - incognitoTabCount

    val pinnedTabs: List<BrowserTab> get() = tabs.filter { it.isPinned }

    val unpinnedTabs: List<BrowserTab> get() = tabs.filter { !it.isPinned }

    fun getTabById(id: Long): BrowserTab? = tabs.find { it.id == id }

    fun getTabPosition(id: Long): Int = tabs.indexOfFirst { it.id == id }

    fun getNextTab(currentId: Long): BrowserTab? {
        val currentIndex = getTabPosition(currentId)
        if (currentIndex == -1) return null
        val nextIndex = (currentIndex + 1) % tabs.size
        return tabs.getOrNull(nextIndex)
    }

    fun getPreviousTab(currentId: Long): BrowserTab? {
        val currentIndex = getTabPosition(currentId)
        if (currentIndex == -1) return null
        val prevIndex = (currentIndex - 1 + tabs.size) % tabs.size
        return tabs.getOrNull(prevIndex)
    }
}

// Tab events
sealed class TabEvent {
    data class TabAdded(val tab: BrowserTab) : TabEvent()
    data class TabRemoved(val tabId: Long) : TabEvent()
    data class TabUpdated(val tab: BrowserTab) : TabEvent()
    data class TabSelected(val tabId: Long) : TabEvent()
    data class TabMoved(val fromPosition: Int, val toPosition: Int) : TabEvent()
    data class TabPinned(val tabId: Long) : TabEvent()
    data class TabUnpinned(val tabId: Long) : TabEvent()
    data class TabGroupCreated(val group: TabGroup) : TabEvent()
    data class TabGroupUpdated(val group: TabGroup) : TabEvent()
    data class TabGroupDeleted(val groupId: Long) : TabEvent()
    data class SessionSaved(val session: TabSession) : TabEvent()
    data class SessionRestored(val sessionId: String) : TabEvent()
    data class SessionDeleted(val sessionId: String) : TabEvent()
    object AllTabsClosed : TabEvent()
    object IncognitoTabsClosed : TabEvent()
    data class Error(val message: String) : TabEvent()
}