package com.viaadvancedbrowser.data.local.database.dao

import androidx.room.*
import com.viaadvancedbrowser.data.model.BrowserTab
import kotlinx.coroutines.flow.Flow

@Dao
interface TabDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(tab: BrowserTab): Long

    @Update
    suspend fun update(tab: BrowserTab)

    @Delete
    suspend fun delete(tab: BrowserTab)

    @Query("SELECT * FROM tabs WHERE isClosed = 0 ORDER BY position ASC")
    fun getAllActiveTabs(): Flow<List<BrowserTab>>

    @Query("SELECT * FROM tabs WHERE id = :tabId")
    suspend fun getTabById(tabId: Long): BrowserTab?

    @Query("SELECT * FROM tabs WHERE sessionId = :sessionId AND isClosed = 0 ORDER BY position ASC")
    suspend fun getTabsBySession(sessionId: String): List<BrowserTab>

    @Query("SELECT * FROM tabs WHERE isIncognito = :incognito AND isClosed = 0 ORDER BY position ASC")
    suspend fun getTabsByIncognito(incognito: Boolean): List<BrowserTab>

    @Query("SELECT * FROM tabs WHERE isPinned = 1 AND isClosed = 0 ORDER BY position ASC")
    suspend fun getPinnedTabs(): List<BrowserTab>

    @Query("UPDATE tabs SET isClosed = 1 WHERE id = :tabId")
    suspend fun closeTab(tabId: Long)

    @Query("UPDATE tabs SET isClosed = 1 WHERE isIncognito = 1")
    suspend fun closeAllIncognitoTabs()

    @Query("UPDATE tabs SET isClosed = 1")
    suspend fun closeAllTabs()

    @Query("UPDATE tabs SET position = :position WHERE id = :tabId")
    suspend fun updateTabPosition(tabId: Long, position: Int)

    @Query("SELECT COUNT(*) FROM tabs WHERE isClosed = 0")
    suspend fun getActiveTabCount(): Int

    @Query("SELECT COUNT(*) FROM tabs WHERE isIncognito = 1 AND isClosed = 0")
    suspend fun getIncognitoTabCount(): Int

    @Query("DELETE FROM tabs WHERE isClosed = 1 AND lastAccessed < :timestamp")
    suspend fun cleanupClosedTabs(timestamp: Long)

    @Query("SELECT * FROM tabs WHERE isClosed = 1 ORDER BY lastAccessed DESC")
    suspend fun getRecentlyClosedTabs(limit: Int = 10): List<BrowserTab>

    @Query("UPDATE tabs SET isClosed = 0 WHERE id = :tabId")
    suspend fun restoreTab(tabId: Long)
}