package com.viaadvancedbrowser.ui.viewmodels

import android.app.Application
import android.webkit.WebView
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.viaadvancedbrowser.data.repository.BrowserRepository
import com.viaadvancedbrowser.features.webview.EnhancedWebChromeClient
import com.viaadvancedbrowser.features.webview.EnhancedWebViewClient
import com.viaadvancedbrowser.utils.UserAgentManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BrowserViewModel @Inject constructor(
    application: Application,
    private val repository: BrowserRepository
) : AndroidViewModel(application) {

    private val _currentUrl = MutableLiveData<String>()
    val currentUrl: LiveData<String> = _currentUrl

    private val _pageTitle = MutableLiveData<String>()
    val pageTitle: LiveData<String> = _pageTitle

    private val _loadingProgress = MutableLiveData<Int>()
    val loadingProgress: LiveData<Int> = _loadingProgress

    private val _snackbarMessage = MutableLiveData<String>()
    val snackbarMessage: LiveData<String> = _snackbarMessage

    // Settings flows
    val isDesktopModeEnabled = repository.isDesktopModeEnabled.asLiveData()
    val isAdBlockEnabled = repository.isAdBlockEnabled.asLiveData()
    val isJavaScriptEnabled = repository.isJavaScriptEnabled.asLiveData()
    val currentTheme = repository.currentTheme.asLiveData()

    fun loadUrl(url: String) {
        val processedUrl = processUrl(url)
        _currentUrl.value = processedUrl
    }

    fun processUrl(url: String): String {
        return if (!url.startsWith("http://") && !url.startsWith("https://")) {
            if (url.contains(".") && !url.contains(" ")) {
                "https://$url"
            } else {
                "https://www.google.com/search?q=${url.replace(" ", "+")}"
            }
        } else {
            url
        }
    }

    fun loadHomePage() {
        viewModelScope.launch {
            val homePage = repository.getHomePage()
            loadUrl(homePage)
        }
    }

    fun getRandomDesktopUserAgent(): String {
        return UserAgentManager.getRandomDesktopUserAgent()
    }

    fun createWebViewClient(): EnhancedWebViewClient {
        return EnhancedWebViewClient(
            context = getApplication(),
            adBlockerEnabled = isAdBlockEnabled.value ?: true,
            desktopModeEnabled = isDesktopModeEnabled.value ?: false
        )
    }

    fun createWebChromeClient(activity: android.app.Activity): EnhancedWebChromeClient {
        return EnhancedWebChromeClient(activity).apply {
            onProgressChanged = { progress ->
                _loadingProgress.postValue(progress)
            }

            onReceivedTitle = { title ->
                _pageTitle.postValue(title)
            }
        }
    }

    fun handleDownload(url: String, contentDisposition: String, mimeType: String) {
        viewModelScope.launch {
            repository.handleDownload(url, contentDisposition, mimeType)
            _snackbarMessage.postValue("Download started")
        }
    }

    fun setDesktopMode(enabled: Boolean) {
        viewModelScope.launch {
            repository.setDesktopMode(enabled)
        }
    }

    fun getCurrentTheme(): Int {
        return currentTheme.value ?: 2
    }
}