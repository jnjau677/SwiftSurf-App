package com.viaadvancedbrowser.ui.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.*
import com.google.android.material.snackbar.Snackbar
import com.viaadvancedbrowser.R
import com.viaadvancedbrowser.databinding.ActivityMainBinding
import com.viaadvancedbrowser.features.player.SnackPlayerManager
import com.viaadvancedbrowser.features.toolbar.AutoSandwichToolbar
import com.viaadvancedbrowser.ui.viewmodels.BrowserViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainBrowserActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: BrowserViewModel by viewModels()
    private lateinit var autoToolbar: AutoSandwichToolbar
    private lateinit var snackPlayerManager: SnackPlayerManager

    private var isFullScreen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure window for immersive experience
        configureWindow()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupWindowInsets()
        initializeComponents()
        setupWebView()
        setupObservers()
        setupToolbar()
        setupSnackPlayer()
        handleIntent(intent)
    }

    private fun configureWindow() {
        WindowCompat.setDecorFitsSystemWindows(window, false)

        window.apply {
            statusBarColor = Color.TRANSPARENT
            navigationBarColor = Color.TRANSPARENT

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                attributes.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())

            view.updatePadding(
                top = systemBars.top,
                bottom = systemBars.bottom + ime.bottom
            )

            // Update toolbar position
            binding.toolbar.updateLayoutParams<ViewGroup.MarginLayoutParams> {
                topMargin = systemBars.top
            }

            insets
        }
    }

    private fun initializeComponents() {
        autoToolbar = AutoSandwichToolbar(
            toolbar = binding.toolbar,
            bottomBar = binding.bottomNavigation,
            webView = binding.webView,
            activity = this
        )

        snackPlayerManager = SnackPlayerManager(
            context = this,
            rootView = binding.root,
            webView = binding.webView
        )
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        with(binding.webView) {
            // Configure WebView settings
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                loadWithOverviewMode = true
                useWideViewPort = true
                loadsImagesAutomatically = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                cacheMode = WebSettings.LOAD_DEFAULT
                setAppCacheEnabled(true)

                // Security settings
                allowFileAccess = false
                allowContentAccess = false
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false

                // Set user agent if desktop mode is enabled
                if (viewModel.isDesktopModeEnabled.value == true) {
                    userAgentString = viewModel.getRandomDesktopUserAgent()
                }
            }

            // Enable hardware acceleration
            setLayerType(View.LAYER_TYPE_HARDWARE, null)

            // Set custom clients
            webViewClient = viewModel.createWebViewClient()
            webChromeClient = viewModel.createWebChromeClient(this@MainBrowserActivity)

            // Set download listener
            setDownloadListener { url, userAgent, contentDisposition, mimetype, contentLength ->
                viewModel.handleDownload(url, contentDisposition, mimetype)
            }
        }
    }

    private fun setupObservers() {
        viewModel.currentUrl.observe(this) { url ->
            binding.urlBar.setText(url)
        }

        viewModel.pageTitle.observe(this) { title ->
            binding.toolbarTitle.text = title ?: getString(R.string.app_name)
        }

        viewModel.loadingProgress.observe(this) { progress ->
            binding.progressBar.progress = progress
            binding.progressBar.isVisible = progress < 100 && progress > 0
        }

        viewModel.snackbarMessage.observe(this) { message ->
            message?.let { showSnackbar(it) }
        }
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        binding.btnBack.setOnClickListener { binding.webView.goBack() }
        binding.btnForward.setOnClickListener { binding.webView.goForward() }
        binding.btnRefresh.setOnClickListener {
            if (binding.webView.progress < 100) {
                binding.webView.stopLoading()
            } else {
                binding.webView.reload()
            }
        }

        binding.urlBar.setOnEditorActionListener { _, _, _ ->
            val url = binding.urlBar.text.toString().trim()
            if (url.isNotEmpty()) {
                viewModel.loadUrl(url)
            }
            binding.urlBar.clearFocus()
            true
        }
    }

    private fun setupSnackPlayer() {
        snackPlayerManager.attachToActivity(this)
    }

    private fun handleIntent(intent: Intent) {
        when (intent.action) {
            Intent.ACTION_VIEW -> {
                val url = intent.dataString
                url?.let { viewModel.loadUrl(it) }
            }
            else -> viewModel.loadHomePage()
        }
    }

    private fun showSnackbar(message: String, duration: Int = Snackbar.LENGTH_SHORT) {
        Snackbar.make(binding.root, message, duration)
            .setAnchorView(binding.bottomNavigation)
            .show()
    }

    override fun onBackPressed() {
        when {
            snackPlayerManager.isPlayerVisible() -> snackPlayerManager.hidePlayer()
            binding.webView.canGoBack() -> binding.webView.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        binding.webView.onResume()
    }

    override fun onPause() {
        super.onPause()
        binding.webView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.webView.destroy()
        snackPlayerManager.release()
    }
}