package com.viaadvancedbrowser.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.viaadvancedbrowser.R
import com.viaadvancedbrowser.data.local.database.entity.HistoryEntity
import com.viaadvancedbrowser.databinding.ItemHistoryBinding
import java.text.SimpleDateFormat
import java.util.*

class HistoryAdapter(
    private val onItemClick: (HistoryEntity) -> Unit,
    private val onItemDelete: (HistoryEntity) -> Unit
) : ListAdapter<HistoryEntity, HistoryAdapter.HistoryViewHolder>(HistoryDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val binding = ItemHistoryBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return HistoryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class HistoryViewHolder(
        private val binding: ItemHistoryBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(history: HistoryEntity) {
            binding.apply {
                historyTitle.text = history.title
                historyUrl.text = history.url

                // Format date
                val formatter = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())
                historyTime.text = formatter.format(Date(history.timestamp))

                // Load favicon
                Glide.with(root.context)
                    .load("https://www.google.com/s2/favicons?domain=${getDomain(history.url)}&sz=32")
                    .placeholder(R.drawable.ic_history)
                    .into(historyFavicon)

                // Set listeners
                root.setOnClickListener { onItemClick(history) }
                btnDelete.setOnClickListener { onItemDelete(history) }
            }
        }

        private fun getDomain(url: String): String {
            return try {
                val uri = java.net.URI(url)
                uri.host ?: url
            } catch (e: Exception) {
                url
            }
        }
    }

    class HistoryDiffCallback : DiffUtil.ItemCallback<HistoryEntity>() {
        override fun areItemsTheSame(oldItem: HistoryEntity, newItem: HistoryEntity): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: HistoryEntity, newItem: HistoryEntity): Boolean {
            return oldItem == newItem
        }
    }
}