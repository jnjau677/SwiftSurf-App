package com.viaadvancedbrowser.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.viaadvancedbrowser.R
import com.viaadvancedbrowser.data.model.BrowserTab
import com.viaadvancedbrowser.databinding.ItemTabBinding
import java.text.SimpleDateFormat
import java.util.*

class TabAdapter(
    private val onTabClick: (BrowserTab) -> Unit,
    private val onTabClose: (BrowserTab) -> Unit
) : ListAdapter<BrowserTab, TabAdapter.TabViewHolder>(TabDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TabViewHolder {
        val binding = ItemTabBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return TabViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TabViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class TabViewHolder(
        private val binding: ItemTabBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(tab: BrowserTab) {
            binding.apply {
                tabTitle.text = tab.title
                tabUrl.text = tab.url

                // Format time
                val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
                tabTime.text = formatter.format(Date(tab.timestamp))

                // Load favicon
                tab.favicon?.let {
                    Glide.with(root.context)
                        .load(it)
                        .placeholder(R.drawable.ic_web)
                        .into(tabFavicon)
                } ?: run {
                    tabFavicon.setImageResource(R.drawable.ic_web)
                }

                // Set listeners
                root.setOnClickListener { onTabClick(tab) }
                btnClose.setOnClickListener { onTabClose(tab) }
            }
        }
    }

    class TabDiffCallback : DiffUtil.ItemCallback<BrowserTab>() {
        override fun areItemsTheSame(oldItem: BrowserTab, newItem: BrowserTab): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: BrowserTab, newItem: BrowserTab): Boolean {
            return oldItem == newItem
        }
    }
}