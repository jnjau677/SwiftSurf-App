package com.viaadvancedbrowser.ui.views

import android.content.Context
import android.util.AttributeSet
import android.webkit.WebView
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.viaadvancedbrowser.features.adblock.AdBlocker

class AdvancedWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {

    private var adBlocker: AdBlocker? = null
    private var isAdBlockEnabled = true

    init {
        initialize(context)
    }

    private fun initialize(context: Context) {
        // Initialize ad blocker if enabled
        if (isAdBlockEnabled) {
            adBlocker = AdBlocker(context)
        }

        // Force dark mode if system is in dark mode
        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(
                settings,
                WebSettingsCompat.FORCE_DARK_AUTO
            )
        }
    }

    override fun loadUrl(url: String) {
        if (isAdBlockEnabled && adBlocker?.isAd(url) == true) {
            // Block ad URLs
            return
        }

        // Ensure HTTPS if possible
        val secureUrl = if (url.startsWith("http://")) {
            "https://${url.substring(7)}"
        } else {
            url
        }

        super.loadUrl(secureUrl)
    }

    override fun loadUrl(url: String, additionalHttpHeaders: MutableMap<String, String>) {
        if (isAdBlockEnabled && adBlocker?.isAd(url) == true) {
            return
        }
        super.loadUrl(url, additionalHttpHeaders)
    }

    fun enableAdBlock(enable: Boolean) {
        isAdBlockEnabled = enable
        if (enable && adBlocker == null) {
            adBlocker = AdBlocker(context)
        }
    }

    fun isAdBlockEnabled(): Boolean = isAdBlockEnabled

    override fun destroy() {
        adBlocker = null
        super.destroy()
    }
}