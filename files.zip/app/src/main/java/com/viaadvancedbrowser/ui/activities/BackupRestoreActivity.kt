package com.viaadvancedbrowser.ui.activities

import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.viaadvancedbrowser.databinding.ActivityBackupRestoreBinding
import com.viaadvancedbrowser.features.backup.BackupManager
import kotlinx.coroutines.launch

class BackupRestoreActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBackupRestoreBinding
    private lateinit var backupManager: BackupManager

    private val createBackupFile = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        uri?.let { createBackup(it) }
    }

    private val openBackupFile = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { restoreBackup(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBackupRestoreBinding.inflate(layoutInflater)
        setContentView(binding.root)

        backupManager = BackupManager(this)
        setupUI()
    }

    private fun setupUI() {
        binding.btnCreateBackup.setOnClickListener {
            createBackupFile.launch("via_backup_${System.currentTimeMillis()}.viaenc")
        }

        binding.btnRestoreBackup.setOnClickListener {
            openBackupFile.launch(arrayOf("application/octet-stream"))
        }
    }

    private fun createBackup(uri: Uri) {
        lifecycleScope.launch {
            binding.progressBar.isVisible = true

            val result = backupManager.createBackup("user_password", uri)

            // Handle result (show messages, etc.)
            binding.progressBar.isVisible = false
        }
    }

    private fun restoreBackup(uri: Uri) {
        lifecycleScope.launch {
            binding.progressBar.isVisible = true

            val result = backupManager.restoreBackup(uri, "user_password")

            // Handle result (show messages, etc.)
            binding.progressBar.isVisible = false
        }
    }
}