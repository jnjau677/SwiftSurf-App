package com.viaadvancedbrowser.ui.activities

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.ListPreference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat
import com.viaadvancedbrowser.R
import com.viaadvancedbrowser.ui.viewmodels.SettingsViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SettingsActivity : AppCompatActivity() {

    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        supportFragmentManager
            .beginTransaction()
            .replace(R.id.settings_container, SettingsFragment())
            .commit()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.title_settings)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    class SettingsFragment : PreferenceFragmentCompat() {

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)

            // Bind preference listeners
            findPreference<SwitchPreferenceCompat>("ad_block")?.setOnPreferenceChangeListener { _, _ ->
                // Handle ad block toggle
                true
            }

            findPreference<SwitchPreferenceCompat>("desktop_mode")?.setOnPreferenceChangeListener { _, _ ->
                // Handle desktop mode toggle
                true
            }

            findPreference<ListPreference>("theme")?.setOnPreferenceChangeListener { _, _ ->
                // Apply theme
                activity?.recreate()
                true
            }
        }
    }
}