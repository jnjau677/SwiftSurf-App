package com.viaadvancedbrowser.ui.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.viaadvancedbrowser.data.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    application: Application,
    private val repository: SettingsRepository
) : AndroidViewModel(application) {

    val theme = repository.currentTheme.asLiveData()
    val desktopMode = repository.isDesktopModeEnabled.asLiveData()
    val adBlock = repository.isAdBlockEnabled.asLiveData()
    val javaScript = repository.isJavaScriptEnabled.asLiveData()
    val homePage = repository.homePage.asLiveData()

    fun setTheme(theme: Int) {
        viewModelScope.launch {
            repository.setTheme(theme)
        }
    }

    fun setDesktopMode(enabled: Boolean) {
        viewModelScope.launch {
            repository.setDesktopMode(enabled)
        }
    }

    fun setAdBlockEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setAdBlockEnabled(enabled)
        }
    }

    fun setJavaScriptEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setJavaScriptEnabled(enabled)
        }
    }

    fun setHomePage(url: String) {
        viewModelScope.launch {
            repository.setHomePage(url)
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllData()
        }
    }
}