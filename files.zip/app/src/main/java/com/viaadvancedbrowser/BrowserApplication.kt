package com.viaadvancedbrowser

import android.app.Application
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import com.google.firebase.FirebaseApp
import com.google.firebase.crashlytics.FirebaseCrashlytics
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

// DataStore extension (top-level to avoid delegate-in-companion issues)
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")
val Context.appDataStore: DataStore<Preferences>
    get() = dataStore

@HiltAndroidApp
class BrowserApplication : Application() {

    companion object {
        private const val TAG = "BrowserApplication"
    }

    override fun onCreate() {
        super.onCreate()

        // Initialize Firebase
        FirebaseApp.initialize(this)

        // Setup logging in debug builds
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
            FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(false)
        } else {
            FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(true)
        }

        // Apply theme from settings
        applyThemeFromPreferences()

        // Initialize app components
        initializeAppComponents()
    }

    private fun applyThemeFromPreferences() {
        val prefs = getSharedPreferences("app_settings", Context.MODE_PRIVATE)
        val theme = prefs.getInt("theme", 2) // 0=light, 1=dark, 2=system

        when (theme) {
            0 -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            1 -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            2 -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    private fun initializeAppComponents() {
        // Initialize database, repositories, etc.
        Timber.d("Browser application initialized")
    }

    override fun onLowMemory() {
        super.onLowMemory()
        Timber.w("Low memory warning - clearing caches")
    }

    override fun onTerminate() {
        super.onTerminate()
        Timber.d("Application terminating")
    }
}