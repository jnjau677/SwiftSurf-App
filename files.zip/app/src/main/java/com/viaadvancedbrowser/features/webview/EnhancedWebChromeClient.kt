package com.viaadvancedbrowser.features.webview

import android.app.Activity
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.appcompat.app.AlertDialog

class EnhancedWebChromeClient(
    private val activity: Activity
) : WebChromeClient() {

    var onProgressChanged: ((Int) -> Unit)? = null
    var onReceivedTitle: ((String?) -> Unit)? = null
    var onReceivedIcon: ((android.graphics.Bitmap) -> Unit)? = null

    override fun onProgressChanged(view: WebView?, newProgress: Int) {
        super.onProgressChanged(view, newProgress)
        onProgressChanged?.invoke(newProgress)
    }

    override fun onReceivedTitle(view: WebView?, title: String?) {
        super.onReceivedTitle(view, title)
        onReceivedTitle?.invoke(title)
    }

    override fun onReceivedIcon(view: WebView?, icon: android.graphics.Bitmap?) {
        super.onReceivedIcon(view, icon)
        icon?.let { onReceivedIcon?.invoke(it) }
    }

    override fun onJsAlert(
        view: WebView?,
        url: String?,
        message: String?,
        result: JsResult
    ): Boolean {
        AlertDialog.Builder(activity)
            .setTitle("Alert")
            .setMessage(message)
            .setPositiveButton("OK") { _, _ -> result.confirm() }
            .setCancelable(false)
            .show()
        return true
    }

    override fun onJsConfirm(
        view: WebView?,
        url: String?,
        message: String?,
        result: JsResult
    ): Boolean {
        AlertDialog.Builder(activity)
            .setTitle("Confirm")
            .setMessage(message)
            .setPositiveButton("OK") { _, _ -> result.confirm() }
            .setNegativeButton("Cancel") { _, _ -> result.cancel() }
            .setCancelable(false)
            .show()
        return true
    }

    override fun onPermissionRequest(request: PermissionRequest?) {
        request?.grant(request.resources)
    }
}