package com.viaadvancedbrowser.features.toolbar

import android.app.Activity
import android.view.View
import android.webkit.WebView
import kotlinx.coroutines.*

class AutoSandwichToolbar(
    private val toolbar: View,
    private val bottomBar: View,
    private val webView: WebView,
    private val activity: Activity
) {

    private val coroutineScope = CoroutineScope(Dispatchers.Main)
    private var hideJob: Job? = null

    init {
        setupScrollListener()
    }

    private fun setupScrollListener() {
        // Setup scroll detection for auto-hide
        // Left intentionally minimal: consumer should wire EnhancedWebView.setOnScrollChangeListener to call show/hide based on scroll delta.
    }

    fun showToolbars() {
        toolbar.animate().alpha(1f).translationY(0f).setDuration(180).start()
        bottomBar.animate().alpha(1f).translationY(0f).setDuration(180).start()
        scheduleAutoHide()
    }

    fun hideToolbars() {
        toolbar.animate().alpha(0f).translationY(-toolbar.height.toFloat()).setDuration(180).start()
        bottomBar.animate().alpha(0f).translationY(bottomBar.height.toFloat()).setDuration(180).start()
        hideJob?.cancel()
    }

    private fun scheduleAutoHide(delayMs: Long = 3000L) {
        hideJob?.cancel()
        hideJob = coroutineScope.launch {
            delay(delayMs)
            hideToolbars()
        }
    }

    fun resume() {
        showToolbars()
    }

    fun pause() {
        hideJob?.cancel()
    }
}