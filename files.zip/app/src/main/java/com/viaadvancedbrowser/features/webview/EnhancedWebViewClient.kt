package com.viaadvancedbrowser.features.webview

import android.content.Context
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.viaadvancedbrowser.features.adblock.AdBlocker
import com.viaadvancedbrowser.utils.UserAgentManager

class EnhancedWebViewClient(
    private val context: Context,
    private val adBlockerEnabled: Boolean,
    private val desktopModeEnabled: Boolean
) : WebViewClient() {

    private val adBlocker = AdBlocker(context)

    override fun shouldInterceptRequest(
        view: WebView,
        request: WebResourceRequest
    ): WebResourceResponse? {
        val url = request.url.toString()

        // Ad blocking
        if (adBlockerEnabled && adBlocker.isAd(url)) {
            return WebResourceResponse("text/plain", "UTF-8", null)
        }

        return super.shouldInterceptRequest(view, request)
    }

    override fun onPageFinished(view: WebView, url: String) {
        super.onPageFinished(view, url)

        // Apply desktop-mode adjustments or inject CSS/JS if needed
        if (desktopModeEnabled) {
            // Inject desktop mode CSS/JS if required
        }
    }

    override fun shouldOverrideUrlLoading(
        view: WebView,
        request: WebResourceRequest
    ): Boolean {
        val url = request.url.toString()

        // Handle special URLs
        return when {
            url.startsWith("tel:") -> {
                // Handle phone calls
                true
            }
            url.startsWith("mailto:") -> {
                // Handle emails
                true
            }
            url.startsWith("intent://") -> {
                // Handle Android intents
                true
            }
            else -> false
        }
    }
}