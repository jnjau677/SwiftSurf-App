package com.viaadvancedbrowser.features.reading

import android.webkit.WebView

class ReadingModeExtractor {

    fun extractReadableContent(webView: WebView, callback: (ReadingContent?) -> Unit) {
        val extractionScript = """
            (function() {
                var article = document.querySelector('article');
                if (!article) {
                    article = document.querySelector('main');
                }
                if (!article) {
                    article = document.body;
                }
                
                return {
                    title: document.title,
                    content: article.innerHTML,
                    textContent: article.textContent,
                    length: article.textContent.length,
                    excerpt: article.textContent.substring(0, 200) + '...'
                };
            })();
        """.trimIndent()

        webView.evaluateJavascript(extractionScript) { result ->
            if (result != null && result != "null") {
                // Parse JSON result
                callback(parseReadingContent(result))
            } else {
                callback(null)
            }
        }
    }

    private fun parseReadingContent(json: String): ReadingContent {
        // Simplified parsing - in production use proper JSON parsing
        return ReadingContent(
            title = "",
            content = "",
            textContent = "",
            length = 0,
            excerpt = ""
        )
    }

    data class ReadingContent(
        val title: String,
        val content: String,
        val textContent: String,
        val length: Int,
        val excerpt: String
    )
}