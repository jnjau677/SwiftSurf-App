package com.viaadvancedbrowser.features.toolbar

import android.content.Context
import android.util.AttributeSet
import android.view.View
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.ViewCompat
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlin.math.abs

/**
 * CoordinatorLayout.Behavior that hides/shows the AppBarLayout and BottomNavigationView
 * when a scrolling target (WebView) scrolls vertically.
 *
 * Apply to a container view in your layout (or use programmatic attachment).
 */
class AutoSandwichBehavior(
    context: Context,
    attrs: AttributeSet? = null
) : CoordinatorLayout.Behavior<View>(context, attrs) {

    private var lastScrollY = 0
    private var toolbar: AppBarLayout? = null
    private var bottomNav: BottomNavigationView? = null

    override fun layoutDependsOn(
        parent: CoordinatorLayout,
        child: View,
        dependency: View
    ): Boolean {
        // Track toolbar and bottom navigation for show/hide actions.
        when (child) {
            is AppBarLayout -> toolbar = child
            is BottomNavigationView -> bottomNav = child
        }

        // Depend on WebView (or any view that reports nested scroll).
        return dependency is android.webkit.WebView
    }

    override fun onStartNestedScroll(
        coordinatorLayout: CoordinatorLayout,
        child: View,
        directTargetChild: View,
        target: View,
        axes: Int,
        type: Int
    ): Boolean {
        return axes == ViewCompat.SCROLL_AXIS_VERTICAL
    }

    override fun onNestedPreScroll(
        coordinatorLayout: CoordinatorLayout,
        child: View,
        target: View,
        dx: Int,
        dy: Int,
        consumed: IntArray,
        type: Int
    ) {
        super.onNestedPreScroll(coordinatorLayout, child, target, dx, dy, consumed, type)

        if (abs(dy) > SCROLL_THRESHOLD) {
            when {
                dy > 0 -> {
                    // Scrolling down - hide both
                    toolbar?.let { hideView(it) }
                    bottomNav?.let { hideView(it) }
                }
                dy < 0 -> {
                    // Scrolling up - show both
                    toolbar?.let { showView(it) }
                    bottomNav?.let { showView(it) }
                }
            }
        }

        lastScrollY = target.scrollY
    }

    override fun onStopNestedScroll(
        coordinatorLayout: CoordinatorLayout,
        child: View,
        target: View,
        type: Int
    ) {
        super.onStopNestedScroll(coordinatorLayout, child, target, type)

        // Show both if at top
        if (target.scrollY == 0) {
            toolbar?.let { showView(it) }
            bottomNav?.let { showView(it) }
        }
    }

    private fun hideView(view: View) {
        if (view.isShown) {
            view.animate()
                .translationY(
                    if (view is AppBarLayout) -view.height.toFloat()
                    else view.height.toFloat()
                )
                .alpha(0f)
                .setDuration(ANIMATION_DURATION)
                .withEndAction {
                    view.visibility = View.GONE
                }
                .start()
        }
    }

    private fun showView(view: View) {
        if (!view.isShown) {
            view.visibility = View.VISIBLE
            view.animate()
                .translationY(0f)
                .alpha(1f)
                .setDuration(ANIMATION_DURATION)
                .start()
        }
    }

    companion object {
        private const val SCROLL_THRESHOLD = 20
        private const val ANIMATION_DURATION = 300L
    }
}