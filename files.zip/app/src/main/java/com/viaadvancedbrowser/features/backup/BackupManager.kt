package com.viaadvancedbrowser.features.backup

import android.content.Context
import android.net.Uri
import android.os.Build
import android.util.Base64
import androidx.documentfile.provider.DocumentFile
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.annotations.Expose
import com.viaadvancedbrowser.data.local.database.AppDatabase
import com.viaadvancedbrowser.data.local.database.dao.BookmarkDao
import com.viaadvancedbrowser.data.local.database.dao.HistoryDao
import com.viaadvancedbrowser.data.local.database.entity.BookmarkEntity
import com.viaadvancedbrowser.data.local.database.entity.HistoryEntity
import com.viaadvancedbrowser.data.local.database.entity.PasswordEntity
import com.viaadvancedbrowser.data.local.datastore.SettingsDataStore
import com.viaadvancedbrowser.features.encryption.EncryptionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.*
import java.security.GeneralSecurityException
import java.text.SimpleDateFormat
import java.util.*
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

@Singleton
class BackupManager @Inject constructor(
    private val context: Context,
    private val database: AppDatabase,
    private val settingsDataStore: SettingsDataStore,
    private val encryptionManager: EncryptionManager
) {

    companion object {
        private const val TAG = "BackupManager"
        private const val BACKUP_VERSION = 1
        private const val ENCRYPTION_ALGORITHM = "AES/CBC/PKCS5Padding"
        private const val KEY_ALGORITHM = "AES"
        private const val BACKUP_FILE_EXTENSION = ".viabackup"
        private const val BACKUP_FOLDER = "ViaBrowserBackups"
    }

    private val gson: Gson = GsonBuilder()
        .excludeFieldsWithoutExposeAnnotation()
        .setPrettyPrinting()
        .create()

    private val dateFormatter = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())

    // Backup data structure
    data class BackupData(
        @Expose val version: Int = BACKUP_VERSION,
        @Expose val timestamp: Long = System.currentTimeMillis(),
        @Expose val deviceName: String = Build.MODEL,
        @Expose val androidVersion: String = Build.VERSION.RELEASE ?: "unknown",
        @Expose val appVersion: String = getAppVersion(),
        @Expose val bookmarks: List<BookmarkEntity> = emptyList(),
        @Expose val history: List<HistoryEntity> = emptyList(),
        @Expose val settings: SettingsBackup = SettingsBackup(),
        @Expose val metadata: Map<String, String> = emptyMap()
    )

    data class SettingsBackup(
        @Expose val homePage: String = "",
        @Expose val searchEngine: String = "",
        @Expose val theme: Int = 0,
        @Expose val desktopMode: Boolean = false,
        @Expose val adBlockEnabled: Boolean = true,
        @Expose val javaScriptEnabled: Boolean = true
    )

    // Result sealed classes
    sealed class BackupResult {
        data class Success(
            val backupFile: File? = null,
            val backupUri: Uri? = null,
            val entryCount: Int,
            val fileSize: Long
        ) : BackupResult()

        data class Failure(
            val errorMessage: String,
            val exception: Exception? = null
        ) : BackupResult()

        object NoData : BackupResult()
    }

    sealed class RestoreResult {
        data class Success(
            val restoredItems: RestoredItems,
            val backupInfo: BackupInfo
        ) : RestoreResult()

        data class Failure(
            val errorMessage: String,
            val exception: Exception? = null
        ) : RestoreResult()

        data class BackupInfo(
            val timestamp: Long,
            val deviceName: String,
            val appVersion: String,
            val itemCounts: ItemCounts
        )

        data class RestoredItems(
            val bookmarks: Int,
            val history: Int,
            val passwords: Int
        )

        data class ItemCounts(
            val bookmarks: Int,
            val history: Int
        )
    }

    /**
     * Create a complete backup with encryption
     */
    suspend fun createBackup(
        backupPassword: String,
        outputUri: Uri? = null,
        includePasswords: Boolean = true
    ): BackupResult = withContext(Dispatchers.IO) {
        try {
            // Collect data (synchronous helpers below wrap dao calls)
            val bookmarks = database.bookmarkDao().getAllSync()
            val history = database.historyDao().getAllSync()

            if (bookmarks.isEmpty() && history.isEmpty()) {
                return@withContext BackupResult.NoData
            }

            // Get settings
            val settings = collectSettings()

            // Create backup data
            val backupData = BackupData(
                bookmarks = bookmarks,
                history = history,
                settings = settings,
                metadata = mapOf(
                    "created_at" to dateFormatter.format(Date()),
                    "item_counts" to "bookmarks:${bookmarks.size},history:${history.size}",
                    "include_passwords" to includePasswords.toString()
                )
            )

            // Convert to JSON
            val jsonData = gson.toJson(backupData)

            // Encrypt and save
            val result = if (outputUri != null) {
                saveEncryptedBackupToUri(jsonData, backupPassword, outputUri)
            } else {
                saveEncryptedBackupToFile(jsonData, backupPassword)
            }

            result
        } catch (e: Exception) {
            BackupResult.Failure("Backup creation failed: ${e.message}", e)
        }
    }

    /**
     * Restore from encrypted backup
     */
    suspend fun restoreBackup(
        backupUri: Uri,
        backupPassword: String,
        conflictStrategy: ConflictStrategy = ConflictStrategy.MERGE
    ): RestoreResult = withContext(Dispatchers.IO) {
        try {
            // Read and decrypt backup
            val jsonData = readEncryptedBackup(backupUri, backupPassword)

            // Parse backup data
            val backupData = gson.fromJson(jsonData, BackupData::class.java)

            // Validate version
            if (backupData.version > BACKUP_VERSION) {
                return@withContext RestoreResult.Failure(
                    "Backup version ${backupData.version} is newer than supported version $BACKUP_VERSION"
                )
            }

            // Restore data
            val restoredItems = restoreData(backupData, conflictStrategy)

            // Restore settings
            restoreSettings(backupData.settings)

            RestoreResult.Success(
                restoredItems = restoredItems,
                backupInfo = RestoreResult.BackupInfo(
                    timestamp = backupData.timestamp,
                    deviceName = backupData.deviceName,
                    appVersion = backupData.appVersion,
                    itemCounts = RestoreResult.ItemCounts(
                        bookmarks = backupData.bookmarks.size,
                        history = backupData.history.size
                    )
                )
            )
        } catch (e: Exception) {
            RestoreResult.Failure("Restore failed: ${e.message}", e)
        }
    }

    /**
     * Validate backup file without restoring
     */
    suspend fun validateBackup(backupUri: Uri, backupPassword: String): ValidationResult {
        return try {
            val jsonData = readEncryptedBackup(backupUri, backupPassword)
            val backupData = gson.fromJson(jsonData, BackupData::class.java)

            ValidationResult(
                isValid = true,
                version = backupData.version,
                timestamp = backupData.timestamp,
                deviceName = backupData.deviceName,
                itemCounts = mapOf(
                    "bookmarks" to backupData.bookmarks.size,
                    "history" to backupData.history.size
                ),
                appVersion = backupData.appVersion,
                canRestore = backupData.version <= BACKUP_VERSION
            )
        } catch (e: Exception) {
            ValidationResult(
                isValid = false,
                errorMessage = e.message ?: "Invalid backup file"
            )
        }
    }

    // Private helper methods

    private suspend fun collectSettings(): SettingsBackup {
        val homePage = settingsDataStore.homePage.first()
        val searchEngine = settingsDataStore.searchEngine.first()
        val theme = settingsDataStore.currentTheme.first()
        val desktopMode = settingsDataStore.desktopModeEnabled.first()
        val adBlockEnabled = settingsDataStore.adBlockEnabled.first()
        val javaScriptEnabled = settingsDataStore.javaScriptEnabled.first()

        return SettingsBackup(
            homePage = homePage,
            searchEngine = searchEngine,
            theme = theme,
            desktopMode = desktopMode,
            adBlockEnabled = adBlockEnabled,
            javaScriptEnabled = javaScriptEnabled
        )
    }

    private suspend fun restoreSettings(settings: SettingsBackup) {
        settingsDataStore.setHomePage(settings.homePage)
        settingsDataStore.setSearchEngine(settings.searchEngine)
        settingsDataStore.setTheme(settings.theme)
        settingsDataStore.setDesktopMode(settings.desktopMode)
        settingsDataStore.setAdBlockEnabled(settings.adBlockEnabled)
        settingsDataStore.setJavaScriptEnabled(settings.javaScriptEnabled)
    }

    private suspend fun restoreData(
        backupData: BackupData,
        conflictStrategy: ConflictStrategy
    ): RestoreResult.RestoredItems {
        val bookmarkDao = database.bookmarkDao()
        val historyDao = database.historyDao()

        var restoredBookmarks = 0
        var restoredHistory = 0

        // Restore bookmarks
        backupData.bookmarks.forEach { bookmark ->
            val existing = bookmarkDao.getByUrlSync(bookmark.url)
            when {
                existing == null -> {
                    bookmarkDao.insert(bookmark)
                    restoredBookmarks++
                }
                conflictStrategy == ConflictStrategy.OVERWRITE -> {
                    bookmarkDao.deleteByUrl(bookmark.url)
                    bookmarkDao.insert(bookmark)
                    restoredBookmarks++
                }
                conflictStrategy == ConflictStrategy.MERGE -> {
                    // Keep both (different IDs)
                    bookmarkDao.insert(bookmark.copy(id = 0))
                    restoredBookmarks++
                }
                // SKIP - do nothing
            }
        }

        // Restore history
        backupData.history.forEach { history ->
            val existing = historyDao.getByUrlSync(history.url)
            when {
                existing == null -> {
                    historyDao.insert(history)
                    restoredHistory++
                }
                conflictStrategy == ConflictStrategy.OVERWRITE -> {
                    historyDao.deleteByUrl(history.url)
                    historyDao.insert(history)
                    restoredHistory++
                }
                conflictStrategy == ConflictStrategy.MERGE -> {
                    // Keep both (different timestamps)
                    historyDao.insert(history.copy(id = 0))
                    restoredHistory++
                }
                // SKIP - do nothing
            }
        }

        return RestoreResult.RestoredItems(
            bookmarks = restoredBookmarks,
            history = restoredHistory,
            passwords = 0 // Password restoration handled separately
        )
    }

    private fun saveEncryptedBackupToFile(
        jsonData: String,
        password: String
    ): BackupResult {
        val backupDir = File(context.getExternalFilesDir(null), BACKUP_FOLDER)
        if (!backupDir.exists()) {
            backupDir.mkdirs()
        }

        val timestamp = dateFormatter.format(Date())
        val backupFile = File(backupDir, "backup_${timestamp}${BACKUP_FILE_EXTENSION}")

        return try {
            FileOutputStream(backupFile).use { outputStream ->
                encryptStream(outputStream, jsonData, password)
            }

            BackupResult.Success(
                backupFile = backupFile,
                entryCount = countItemsInBackup(jsonData),
                fileSize = backupFile.length()
            )
        } catch (e: Exception) {
            BackupResult.Failure("Failed to save backup: ${e.message}", e)
        }
    }

    private fun saveEncryptedBackupToUri(
        jsonData: String,
        password: String,
        uri: Uri
    ): BackupResult {
        return try {
            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                encryptStream(outputStream, jsonData, password)
            }

            BackupResult.Success(
                backupUri = uri,
                entryCount = countItemsInBackup(jsonData),
                fileSize = jsonData.toByteArray(Charsets.UTF_8).size.toLong()
            )
        } catch (e: Exception) {
            BackupResult.Failure("Failed to save backup to URI: ${e.message}", e)
        }
    }

    private fun readEncryptedBackup(uri: Uri, password: String): String {
        return context.contentResolver.openInputStream(uri)?.use { inputStream ->
            decryptStream(inputStream, password)
        } ?: throw IOException("Cannot open backup file")
    }

    private fun encryptStream(outputStream: OutputStream, data: String, password: String) {
        val key = deriveKeyFromPassword(password)
        val iv = ByteArray(16).also { Random.nextBytes(it) }

        val cipher = Cipher.getInstance(ENCRYPTION_ALGORITHM)
        cipher.init(Cipher.ENCRYPT_MODE, key, IvParameterSpec(iv))

        // Write IV first
        outputStream.write(iv)

        // Write encrypted data
        CipherOutputStream(outputStream, cipher).use { cipherStream ->
            cipherStream.write(data.toByteArray(Charsets.UTF_8))
        }
    }

    private fun decryptStream(inputStream: InputStream, password: String): String {
        // Read IV
        val iv = ByteArray(16)
        val read = inputStream.read(iv)
        if (read != iv.size) throw IOException("Invalid backup file (IV)")

        val key = deriveKeyFromPassword(password)
        val cipher = Cipher.getInstance(ENCRYPTION_ALGORITHM)
        cipher.init(Cipher.DECRYPT_MODE, key, IvParameterSpec(iv))

        // Read and decrypt data
        CipherInputStream(inputStream, cipher).use { cipherStream ->
            return cipherStream.bufferedReader().readText()
        }
    }

    private fun deriveKeyFromPassword(password: String): SecretKeySpec {
        val salt = "ViaBrowserBackupSalt".toByteArray(Charsets.UTF_8)
        val iterations = 10000
        val keyLength = 256

        val factory = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = javax.crypto.spec.PBEKeySpec(
            password.toCharArray(),
            salt,
            iterations,
            keyLength
        )

        val tmpKey = factory.generateSecret(spec)
        return SecretKeySpec(tmpKey.encoded, KEY_ALGORITHM)
    }

    private fun countItemsInBackup(jsonData: String): Int {
        return try {
            val backupData = gson.fromJson(jsonData, BackupData::class.java)
            backupData.bookmarks.size + backupData.history.size
        } catch (e: Exception) {
            0
        }
    }

    private fun readBackupMetadata(file: File): BackupData {
        // Read only the beginning of the file to get metadata
        FileInputStream(file).use { inputStream ->
            // Note: This assumes unencrypted / readable JSON — if encrypted, this needs to decrypt metadata
            val reader = inputStream.bufferedReader()
            val firstLine = reader.readLine()
            return gson.fromJson(firstLine, BackupData::class.java)
        }
    }

    private fun getAppVersion(): String {
        return try {
            val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            packageInfo.versionName ?: "unknown"
        } catch (e: Exception) {
            "unknown"
        }
    }

    // Extension functions for synchronous DAO access (wrapping suspend calls)
    private suspend fun BookmarkDao.getAllSync(): List<BookmarkEntity> {
        return withContext(Dispatchers.IO) { this@getAllSync.getAll() }
    }

    private suspend fun HistoryDao.getAllSync(): List<HistoryEntity> {
        return withContext(Dispatchers.IO) { this@getAllSync.getAll() }
    }

    private suspend fun BookmarkDao.getByUrlSync(url: String): BookmarkEntity? {
        return withContext(Dispatchers.IO) { this@getByUrlSync.getByUrl(url) }
    }

    private suspend fun HistoryDao.getByUrlSync(url: String): HistoryEntity? {
        return withContext(Dispatchers.IO) { this@getByUrlSync.getByUrl(url) }
    }
}

// Enums and data classes
enum class ConflictStrategy {
    OVERWRITE,
    SKIP,
    MERGE
}

enum class ExportFormat {
    JSON,
    ENCRYPTED
}

data class ValidationResult(
    val isValid: Boolean,
    val version: Int = 0,
    val timestamp: Long = 0,
    val deviceName: String = "",
    val itemCounts: Map<String, Int> = emptyMap(),
    val appVersion: String = "",
    val errorMessage: String = "",
    val canRestore: Boolean = false
)

data class BackupInfo(
    val file: File,
    val timestamp: Long,
    val size: Long,
    val itemCounts: Map<String, Int>,
    val deviceName: String
)

sealed class ExportResult {
    data class Success(
        val format: ExportFormat,
        val itemCount: Int
    ) : ExportResult()

    data class Failure(
        val errorMessage: String,
        val exception: Exception? = null
    ) : ExportResult()
}