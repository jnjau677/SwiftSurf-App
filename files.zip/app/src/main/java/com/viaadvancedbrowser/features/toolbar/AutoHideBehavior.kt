package com.viaadvancedbrowser.features.toolbar

import android.content.Context
import android.util.AttributeSet
import android.view.View
import androidx.coordinatorlayout.widget.CoordinatorLayout
import com.google.android.material.appbar.AppBarLayout
import kotlin.math.abs

class AutoHideBehavior(context: Context, attrs: AttributeSet) : CoordinatorLayout.Behavior<View>(context, attrs) {

    private var lastScrollY = 0
    private var isToolbarVisible = true

    override fun onStartNestedScroll(
        coordinatorLayout: CoordinatorLayout,
        child: View,
        directTargetChild: View,
        target: View,
        axes: Int,
        type: Int
    ): Boolean {
        return axes == View.SCROLL_AXIS_VERTICAL
    }

    override fun onNestedPreScroll(
        coordinatorLayout: CoordinatorLayout,
        child: View,
        target: View,
        dx: Int,
        dy: Int,
        consumed: IntArray,
        type: Int
    ) {
        super.onNestedPreScroll(coordinatorLayout, child, target, dx, dy, consumed, type)

        if (abs(dy) > 5) { // Ignore small scrolls
            if (dy > 0 && isToolbarVisible) {
                // Scrolling down and toolbar is visible -> hide it
                hideToolbar(child)
                isToolbarVisible = false
            } else if (dy < 0 && !isToolbarVisible) {
                // Scrolling up and toolbar is hidden -> show it
                showToolbar(child)
                isToolbarVisible = true
            }
        }
    }

    private fun hideToolbar(view: View) {
        view.animate()
            .translationY(-view.height.toFloat())
            .setDuration(300)
            .start()
    }

    private fun showToolbar(view: View) {
        view.animate()
            .translationY(0f)
            .setDuration(300)
            .start()
    }

    override fun layoutDependsOn(
        parent: CoordinatorLayout,
        child: View,
        dependency: View
    ): Boolean {
        return dependency is AppBarLayout
    }

    override fun onDependentViewChanged(
        parent: CoordinatorLayout,
        child: View,
        dependency: View
    ): Boolean {
        // You can adjust the behavior based on the AppBarLayout's state if needed
        return super.onDependentViewChanged(parent, child, dependency)
    }
}