package com.veestore.swiftsurf.features.backup

import android.content.Context
import android.net.Uri
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.annotations.Expose
import com.veestore.swiftsurf.data.local.database.AppDatabase
import com.veestore.swiftsurf.data.local.database.entity.BookmarkEntity
import com.veestore.swiftsurf.data.local.database.entity.HistoryEntity
import com.veestore.swiftsurf.data.local.datastore.SettingsDataStore
import com.veestore.swiftsurf.features.encryption.EncryptionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.*
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.*
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Backup format:
 * [4 bytes magic 'VSBF'] [1 byte version] [16 bytes salt] [12 bytes iv] [ciphertext...]
 *
 * AES-GCM used for encryption. Key derived from user password via PBKDF2WithHmacSHA256.
 */
@Singleton
class BackupManager @Inject constructor(
    private val context: Context,
    private val database: AppDatabase,
    private val settingsDataStore: SettingsDataStore,
    private val encryptionManager: EncryptionManager
) {

    companion object {
        private const val MAGIC = "VSBF" // SwiftSurf Backup Format
        private const val VERSION: Byte = 1
        private const val SALT_LEN = 16
        private const val IV_LEN = 12
        private const val KEY_LEN = 256
        private const val PBKDF2_ITER = 100_000 // adjust as needed for device targets
        private const val CIPHER_TRANSFORMATION = "AES/GCM/NoPadding"
    }

    private val gson: Gson = GsonBuilder().excludeFieldsWithoutExposeAnnotation().create()
    private val dateFormatter = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())

    data class BackupData(
        @Expose val version: Int = VERSION.toInt(),
        @Expose val timestamp: Long = System.currentTimeMillis(),
        @Expose val deviceName: String = android.os.Build.MODEL,
        @Expose val androidVersion: String = android.os.Build.VERSION.RELEASE ?: "unknown",
        @Expose val appVersion: String = getAppVersion(),
        @Expose val bookmarks: List<BookmarkEntity> = emptyList(),
        @Expose val history: List<HistoryEntity> = emptyList(),
        @Expose val settings: Map<String, Any> = emptyMap(),
        @Expose val metadata: Map<String, String> = emptyMap()
    )

    sealed class BackupResult {
        data class Success(val file: File) : BackupResult()
        data class Failure(val error: String, val ex: Exception? = null) : BackupResult()
        object NoData : BackupResult()
    }

    /**
     * Create backup and write encrypted file (returns the file)
     */
    suspend fun createBackup(backupPassword: String, outputFile: File? = null): BackupResult = withContext(Dispatchers.IO) {
        try {
            val bookmarks = database.bookmarkDao().getAllSync()
            val history = database.historyDao().getAllSync()
            if (bookmarks.isEmpty() && history.isEmpty()) return@withContext BackupResult.NoData

            val settings = mapOf(
                "homePage" to settingsDataStore.homePage.first(),
                "searchEngine" to settingsDataStore.searchEngine.first()
            )

            val backupData = BackupData(
                bookmarks = bookmarks,
                history = history,
                settings = settings,
                metadata = mapOf("created_at" to dateFormatter.format(Date()))
            )

            val json = gson.toJson(backupData)
            val outFile = outputFile ?: File(context.cacheDir, "swiftsurf_backup_${dateFormatter.format(Date())}.viabackup")

            writeEncryptedBackup(outFile, json.toByteArray(Charsets.UTF_8), backupPassword)
            BackupResult.Success(outFile)
        } catch (e: Exception) {
            BackupResult.Failure("Backup failed: ${e.message}", e)
        }
    }

    /**
     * Restore backup from a content URI (decrypts and inserts data)
     */
    suspend fun restoreBackup(backupUri: Uri, backupPassword: String, conflictStrategy: ConflictStrategy = ConflictStrategy.MERGE): BackupResult = withContext(Dispatchers.IO) {
        try {
            val inputStream = context.contentResolver.openInputStream(backupUri) ?: return@withContext BackupResult.Failure("Cannot open backup Uri")
            val plain = readEncryptedBackup(inputStream, backupPassword)
            val backupData = gson.fromJson(String(plain, Charsets.UTF_8), BackupData::class.java)

            // Validate version
            if (backupData.version > VERSION) {
                return@withContext BackupResult.Failure("Backup version ${backupData.version} is newer than supported version $VERSION")
            }

            // Restore bookmarks and history
            val restoredBookmarks = restoreBookmarks(backupData.bookmarks, conflictStrategy)
            val restoredHistory = restoreHistory(backupData.history, conflictStrategy)

            // Restore settings
            restoreSettingsFromMap(backupData.settings)

            // You could return a more detailed result object; returning file placeholder success for simplicity
            BackupResult.Success(File(""))
        } catch (e: Exception) {
            BackupResult.Failure("Restore failed: ${e.message}", e)
        }
    }

    private suspend fun restoreBookmarks(bookmarks: List<BookmarkEntity>, conflictStrategy: ConflictStrategy): Int {
        var restored = 0
        val dao = database.bookmarkDao()
        bookmarks.forEach { bm ->
            val existing = dao.getByUrlSync(bm.url)
            when {
                existing == null -> {
                    dao.insert(bm)
                    restored++
                }
                conflictStrategy == ConflictStrategy.OVERWRITE -> {
                    dao.deleteByUrl(bm.url)
                    dao.insert(bm)
                    restored++
                }
                conflictStrategy == ConflictStrategy.MERGE -> {
                    dao.insert(bm.copy(id = 0))
                    restored++
                }
                else -> { /* skip */ }
            }
        }
        return restored
    }

    private suspend fun restoreHistory(history: List<HistoryEntity>, conflictStrategy: ConflictStrategy): Int {
        var restored = 0
        val dao = database.historyDao()
        history.forEach { h ->
            val existing = dao.getByUrlSync(h.url)
            when {
                existing == null -> {
                    dao.insert(h)
                    restored++
                }
                conflictStrategy == ConflictStrategy.OVERWRITE -> {
                    dao.deleteByUrl(h.url)
                    dao.insert(h)
                    restored++
                }
                conflictStrategy == ConflictStrategy.MERGE -> {
                    dao.insert(h.copy(id = 0))
                    restored++
                }
                else -> { /* skip */ }
            }
        }
        return restored
    }

    private suspend fun restoreSettingsFromMap(settings: Map<String, Any>) {
        // Map keys depend on what createBackup wrote. We used "homePage" and "searchEngine".
        val home = settings["homePage"] as? String
        val engine = settings["searchEngine"] as? String
        if (!home.isNullOrBlank()) settingsDataStore.setHomePage(home)
        if (!engine.isNullOrBlank()) settingsDataStore.setSearchEngine(engine)
    }

    private fun writeEncryptedBackup(file: File, data: ByteArray, password: String) {
        val salt = ByteArray(SALT_LEN).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(IV_LEN).also { SecureRandom().nextBytes(it) }
        val key = deriveKey(password, salt)
        val cipher = Cipher.getInstance(CIPHER_TRANSFORMATION)
        val spec = GCMParameterSpec(128, iv)
        cipher.init(Cipher.ENCRYPT_MODE, key, spec)
        val cipherText = cipher.doFinal(data)

        FileOutputStream(file).use { fos ->
            fos.write(MAGIC.toByteArray(Charsets.US_ASCII))
            fos.write(byteArrayOf(VERSION))
            fos.write(salt)
            fos.write(iv)
            fos.write(cipherText)
            fos.flush()
        }
    }

    private fun readEncryptedBackup(input: InputStream, password: String): ByteArray {
        val header = ByteArray(MAGIC.length)
        if (input.read(header) != header.size) throw IOException("Invalid backup file")
        if (!MAGIC.toByteArray(Charsets.US_ASCII).contentEquals(header)) throw IOException("Bad magic")

        val version = input.read()
        if (version <= 0) throw IOException("Invalid version")
        val salt = ByteArray(SALT_LEN)
        if (input.read(salt) != SALT_LEN) throw IOException("Missing salt")
        val iv = ByteArray(IV_LEN)
        if (input.read(iv) != IV_LEN) throw IOException("Missing iv")
        val ciphertext = input.readBytes()
        val key = deriveKey(password, salt)
        val cipher = Cipher.getInstance(CIPHER_TRANSFORMATION)
        val spec = GCMParameterSpec(128, iv)
        cipher.init(Cipher.DECRYPT_MODE, key, spec)
        return cipher.doFinal(ciphertext)
    }

    private fun deriveKey(password: String, salt: ByteArray): SecretKey {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(password.toCharArray(), salt, PBKDF2_ITER, KEY_LEN)
        val tmp = factory.generateSecret(spec)
        return SecretKeySpec(tmp.encoded, "AES")
    }

    private fun getAppVersion(): String {
        return try {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            info.versionName ?: "unknown"
        } catch (e: Exception) {
            "unknown"
        }
    }
}

// ConflictStrategy enum (used by restore)
enum class ConflictStrategy {
    OVERWRITE,
    SKIP,
    MERGE
}