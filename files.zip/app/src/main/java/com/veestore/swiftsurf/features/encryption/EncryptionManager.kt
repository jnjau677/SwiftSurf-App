package com.veestore.swiftsurf.features.encryption

import android.content.Context
import androidx.security.crypto.MasterKey

/**
 * Helper providing MasterKey for AndroidX Security operations.
 * Use MasterKey.getOrCreate for encryption helpers such as EncryptedFile or EncryptedSharedPreferences.
 */
class EncryptionManager(private val context: Context) {

    private val masterKey: MasterKey by lazy {
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    fun getMasterKey(): MasterKey = masterKey
}