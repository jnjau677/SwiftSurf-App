package com.veestore.swiftsurf

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

@HiltAndroidApp
class BrowserApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        // Timber for logging; optional
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
    }
}