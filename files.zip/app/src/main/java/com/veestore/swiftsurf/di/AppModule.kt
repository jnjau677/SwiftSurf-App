package com.veestore.swiftsurf.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import com.veestore.swiftsurf.features.encryption.EncryptionManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import dagger.hilt.android.qualifiers.ApplicationContext
import com.google.gson.Gson

private val Context.appPreferencesDataStore: DataStore<Preferences> by preferencesDataStore(name = "swiftsurf_prefs")

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    fun providePreferencesDataStore(@ApplicationContext context: Context): DataStore<Preferences> =
        context.appPreferencesDataStore

    @Provides
    @Singleton
    fun provideEncryptionManager(@ApplicationContext context: Context): EncryptionManager =
        EncryptionManager(context)

    @Provides
    @Singleton
    fun provideGson(): Gson = Gson()
}