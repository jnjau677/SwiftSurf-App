package com.veestore.swiftsurf.features.webview

import android.content.Context
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.veestore.swiftsurf.features.adblock.AdBlocker

class EnhancedWebViewClient(
    private val context: Context,
    private val adBlockerEnabled: Boolean,
    private val desktopModeEnabled: Boolean
) : WebViewClient() {

    private val adBlocker = AdBlocker(context)

    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
        val url = request.url.toString()
        if (adBlockerEnabled && adBlocker.isAd(url)) {
            return WebResourceResponse("text/plain", "UTF-8", null)
        }
        return super.shouldInterceptRequest(view, request)
    }

    override fun onPageFinished(view: WebView, url: String) {
        super.onPageFinished(view, url)
        if (desktopModeEnabled) {
            // Optionally inject CSS/JS to simulate desktop mode
        }
    }

    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
        val url = request.url.toString()
        return when {
            url.startsWith("tel:") -> {
                // handle
                true
            }
            url.startsWith("mailto:") -> {
                // handle
                true
            }
            url.startsWith("intent://") -> {
                // handle
                true
            }
            else -> false
        }
    }
}