package com.veestore.swiftsurf.ui.activities

import android.os.Bundle
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.veestore.swiftsurf.R
import com.veestore.swiftsurf.repository.UserAgentRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class MainBrowserActivity : AppCompatActivity() {

    @Inject
    lateinit var userAgentRepository: UserAgentRepository

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)

        // Basic WebView settings (you may have more in EnhancedWebView/AdvancedWebView)
        webView.settings.javaScriptEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.settings.domStorageEnabled = true

        // Observe the current user agent and apply it to the WebView.
        // When UA changes, we update the settings and reload the current page if already loaded.
        lifecycleScope.launch {
            userAgentRepository.currentUserAgent.collect { ua ->
                val settings = webView.settings
                if (settings.userAgentString != ua) {
                    settings.userAgentString = ua
                    // If a page is already loaded, reload so the UA takes effect immediately.
                    if (!webView.url.isNullOrBlank()) {
                        webView.reload()
                    }
                }
            }
        }

        // Load home page or a default page if desired
        // You can also collect SettingsDataStore.homePage in a ViewModel and use it here.
        if (webView.url.isNullOrBlank()) {
            webView.loadUrl("https://www.google.com")
        }
    }
}