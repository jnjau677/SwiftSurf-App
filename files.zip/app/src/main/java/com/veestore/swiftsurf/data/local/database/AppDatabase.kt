package com.veestore.swiftsurf.data.local.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.veestore.swiftsurf.data.local.database.dao.BookmarkDao
import com.veestore.swiftsurf.data.local.database.dao.HistoryDao
import com.veestore.swiftsurf.data.local.database.dao.TabDao
import com.veestore.swiftsurf.data.local.database.dao.PasswordDao
import com.veestore.swiftsurf.data.model.BrowserTab
import com.veestore.swiftsurf.data.local.database.entity.BookmarkEntity
import com.veestore.swiftsurf.data.local.database.entity.HistoryEntity
import com.veestore.swiftsurf.data.local.database.entity.PasswordEntity

@Database(
    entities = [BrowserTab::class, BookmarkEntity::class, HistoryEntity::class, PasswordEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tabDao(): com.veestore.swiftsurf.data.local.database.dao.TabDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun historyDao(): HistoryDao
    abstract fun passwordDao(): PasswordDao
}