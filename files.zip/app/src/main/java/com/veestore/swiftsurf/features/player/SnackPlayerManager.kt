package com.veestore.swiftsurf.features.player

import android.app.Activity
import android.content.Context
import android.view.*
import android.widget.FrameLayout
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.ui.PlayerView

class SnackPlayerManager(
    private val context: Context,
    private val rootView: ViewGroup,
    private val webView: android.webkit.WebView
) {

    private var playerView: PlayerView? = null
    private var player: ExoPlayer? = null
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    fun attachToActivity(activity: Activity) {
        initializePlayer()
        createPlayerView()
    }

    fun showPlayer(videoUrl: String? = null) {
        playerView?.let { pv ->
            if (pv.parent == null) {
                val params = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    leftMargin = 16
                    topMargin = 100
                }
                rootView.addView(pv, params)
            }
            // TODO: prepare media source if videoUrl provided and start playback
        }
    }

    fun hidePlayer() {
        playerView?.let { pv ->
            (pv.parent as? ViewGroup)?.removeView(pv)
        }
    }

    fun isPlayerVisible(): Boolean {
        return playerView?.parent != null
    }

    fun release() {
        playerView = null
        player?.release()
        player = null
    }

    private fun initializePlayer() {
        player = ExoPlayer.Builder(context).build()
    }

    private fun createPlayerView() {
        if (playerView != null) return
        playerView = PlayerView(context).apply {
            useController = true
            player = this@SnackPlayerManager.player
            // Simple draggable behavior
            setOnTouchListener(DraggableTouchListener())
            layoutParams = FrameLayout.LayoutParams(
                context.resources.displayMetrics.widthPixels / 2,
                (context.resources.displayMetrics.heightPixels / 4)
            )
        }
    }

    private inner class DraggableTouchListener : View.OnTouchListener {
        private var lastX = 0f
        private var lastY = 0f
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.rawX
                    lastY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - lastX
                    val dy = event.rawY - lastY
                    v.x = v.x + dx
                    v.y = v.y + dy
                    lastX = event.rawX
                    lastY = event.rawY
                    return true
                }
            }
            return false
        }
    }
}