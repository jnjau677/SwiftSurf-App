package com.veestore.swiftsurf.di

import android.content.Context
import androidx.room.Room
import com.veestore.swiftsurf.data.local.database.AppDatabase
import com.veestore.swiftsurf.data.local.database.dao.BookmarkDao
import com.veestore.swiftsurf.data.local.database.dao.HistoryDao
import com.veestore.swiftsurf.data.local.database.dao.TabDao
import com.veestore.swiftsurf.data.local.database.dao.PasswordDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import dagger.hilt.android.qualifiers.ApplicationContext

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    private const val DB_NAME = "swiftsurf.db"

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext appContext: Context): AppDatabase {
        return Room.databaseBuilder(appContext, AppDatabase::class.java, DB_NAME)
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides fun provideTabDao(db: AppDatabase): TabDao = db.tabDao()
    @Provides fun provideBookmarkDao(db: AppDatabase): BookmarkDao = db.bookmarkDao()
    @Provides fun provideHistoryDao(db: AppDatabase): HistoryDao = db.historyDao()
    @Provides fun providePasswordDao(db: AppDatabase): PasswordDao = db.passwordDao()
}