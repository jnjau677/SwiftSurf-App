package com.veestore.swiftsurf.ui.viewmodels

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.veestore.swiftsurf.data.local.datastore.SettingsDataStore
import com.veestore.swiftsurf.repository.UserAgentRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
import dagger.hilt.android.qualifiers.ApplicationContext

@HiltViewModel
class UserAgentViewModel @Inject constructor(
    private val repo: UserAgentRepository,
    private val settingsDataStore: SettingsDataStore,
    @ApplicationContext private val context: Context
) : ViewModel() {

    val availableUserAgents: Flow<List<String>> = flow {
        emit(repo.getAvailableUserAgents())
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val currentUserAgent: Flow<String> = repo.currentUserAgent

    fun selectUserAgentByIndex(index: Int) {
        viewModelScope.launch {
            settingsDataStore.setCustomUserAgent(null) // clear custom when selecting built-in
            settingsDataStore.setUserAgentIndex(index)
        }
    }

    fun setCustomUserAgent(ua: String?) {
        viewModelScope.launch {
            settingsDataStore.setCustomUserAgent(ua)
        }
    }

    fun isCustomSelected(candidate: String?): Boolean {
        // custom if candidate is not in built-in list
        val builtIns = repo.getAvailableUserAgents()
        return candidate != null && !builtIns.contains(candidate)
    }
}