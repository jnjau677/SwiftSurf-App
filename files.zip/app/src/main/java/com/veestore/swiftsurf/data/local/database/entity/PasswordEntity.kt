package com.veestore.swiftsurf.data.local.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "passwords")
data class PasswordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val domain: String,
    val username: String,
    val passwordEncrypted: String,
    val noteEncrypted: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)