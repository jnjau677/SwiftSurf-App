package com.veestore.swiftsurf.features.vpn

import android.net.VpnService
import android.os.ParcelFileDescriptor
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import android.content.Intent
import com.veestore.swiftsurf.BuildConfig

class BrowserVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var isRunning = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> startVPN()
            ACTION_DISCONNECT -> stopVPN()
        }
        return START_STICKY
    }

    private fun startVPN() {
        try {
            val builder = Builder()
            builder.setSession("SwiftSurf VPN")
                .addAddress("10.0.0.2", 32)
                .addDnsServer("1.1.1.1")
                .addDnsServer("1.0.0.1")
                .addRoute("0.0.0.0", 0)
                .setMtu(1500)
                .setBlocking(true)

            // Allow only our app to bypass VPN
            builder.addAllowedApplication(BuildConfig.APPLICATION_ID)

            vpnInterface = builder.establish()
            isRunning = true

            sendBroadcast(STATUS_CONNECTED)

            Thread(VpnRunnable(vpnInterface!!)).start()

        } catch (e: Exception) {
            stopVPN()
        }
    }

    private fun stopVPN() {
        isRunning = false
        try {
            vpnInterface?.close()
        } catch (_: Exception) { }
        vpnInterface = null
        sendBroadcast(STATUS_DISCONNECTED)
        stopSelf()
    }

    private fun sendBroadcast(status: String) {
        val intent = Intent(ACTION_VPN_STATUS)
        intent.putExtra(EXTRA_STATUS, status)
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
    }

    override fun onDestroy() {
        stopVPN()
        super.onDestroy()
    }

    fun isRunning(): Boolean = isRunning

    private inner class VpnRunnable(
        private val vpnInterface: ParcelFileDescriptor
    ) : Runnable {
        override fun run() {
            // Placeholder - read/write from vpnInterface.fileDescriptor
        }
    }

    companion object {
        const val ACTION_CONNECT = "connect"
        const val ACTION_DISCONNECT = "disconnect"
        const val ACTION_VPN_STATUS = "vpn_status"
        const val EXTRA_STATUS = "status"
        const val STATUS_CONNECTED = "connected"
        const val STATUS_DISCONNECTED = "disconnected"
    }
}