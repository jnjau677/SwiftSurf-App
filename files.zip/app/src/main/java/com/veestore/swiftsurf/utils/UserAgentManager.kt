package com.veestore.swiftsurf.utils

import android.content.Context
import com.veestore.swiftsurf.BuildConfig
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlin.random.Random

object UserAgentManager {

    // Primary list parsed from BuildConfig JSON
    private val desktopUserAgentsFromBuildConfig: List<String> by lazy {
        val json = try { BuildConfig.DESKTOP_USER_AGENTS_JSON } catch (e: Exception) { "[]" }
        val gson = Gson()
        try {
            val type = object : TypeToken<List<String>>() {}.type
            gson.fromJson<List<String>>(json, type) ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun defaultUserAgent(): String =
        "Mozilla/5.0 (Android) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36"

    /**
     * Returns the available desktop user agents, trying in order:
     * 1) BuildConfig JSON
     * 2) resources array R.array.desktop_user_agents (requires context)
     * 3) a small default list with one element
     */
    fun getAvailableUserAgents(context: Context?): List<String> {
        if (desktopUserAgentsFromBuildConfig.isNotEmpty()) return desktopUserAgentsFromBuildConfig
        if (context != null) {
            try {
                val arr = context.resources.getStringArray(com.veestore.swiftsurf.R.array.desktop_user_agents)
                if (arr.isNotEmpty()) return arr.toList()
            } catch (_: Exception) { /* fallback below */ }
        }
        return listOf(defaultUserAgent())
    }

    fun getRandomDesktopUserAgent(context: Context?): String {
        val list = getAvailableUserAgents(context)
        return list[Random.nextInt(list.size)]
    }

    fun isDesktopUserAgent(userAgent: String, context: Context?): Boolean {
        return getAvailableUserAgents(context).any { it == userAgent }
    }
}