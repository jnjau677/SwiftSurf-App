package com.veestore.swiftsurf.data.local.database.dao

import androidx.room.*
import com.veestore.swiftsurf.data.local.database.entity.PasswordEntity

@Dao
interface PasswordDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(password: PasswordEntity): Long

    @Query("SELECT * FROM passwords WHERE id = :id")
    suspend fun getById(id: Long): PasswordEntity?

    @Query("SELECT * FROM passwords WHERE domain = :domain")
    suspend fun getByDomain(domain: String): List<PasswordEntity>

    @Query("DELETE FROM passwords WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM passwords")
    suspend fun deleteAll()
}