package com.veestore.swiftsurf.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.veestore.swiftsurf.databinding.FragmentUserAgentSettingsBinding
import com.veestore.swiftsurf.ui.adapters.UserAgentAdapter
import com.veestore.swiftsurf.ui.viewmodels.UserAgentViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class UserAgentSettingsFragment : Fragment() {

    private var _binding: FragmentUserAgentSettingsBinding? = null
    private val binding get() = _binding!!
    private val vm: UserAgentViewModel by viewModels()
    private lateinit var adapter: UserAgentAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentUserAgentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter = UserAgentAdapter { ua, index ->
            // User selected a UA from the list
            lifecycleScope.launchWhenStarted {
                vm.selectUserAgentByIndex(index)
            }
        }

        binding.recyclerUserAgents.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerUserAgents.adapter = adapter

        binding.btnSetCustom.setOnClickListener {
            val custom = binding.editCustomUa.text?.toString()?.trim()
            lifecycleScope.launchWhenStarted {
                vm.setCustomUserAgent(if (custom.isNullOrBlank()) null else custom)
            }
        }

        binding.editCustomUa.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                binding.btnSetCustom.performClick()
                true
            } else false
        }

        // Observe available UAs and selection
        viewLifecycleOwner.lifecycleScope.launchWhenStarted {
            vm.availableUserAgents.collectLatest { list ->
                adapter.submitList(list)
            }
        }

        viewLifecycleOwner.lifecycleScope.launchWhenStarted {
            vm.currentUserAgent.collectLatest { current ->
                adapter.setSelectedUserAgent(current)
                binding.editCustomUa.setText(if (vm.isCustomSelected(current)) current else "")
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}