package com.veestore.swiftsurf.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.veestore.swiftsurf.features.backup.BackupManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class BackupWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    @Inject
    lateinit var backupManager: BackupManager

    override suspend fun doWork(): Result {
        return withContext(Dispatchers.IO) {
            try {
                // Example: perform a backup with a preconfigured password (in practice ask the user)
                Result.success()
            } catch (e: Exception) {
                Result.failure()
            }
        }
    }
}