package com.veestore.swiftsurf.data.model

import android.graphics.Bitmap
import android.os.Parcelable
import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*

@Entity(tableName = "tabs")
@Parcelize
data class BrowserTab(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String = "",
    val url: String = "",
    val originalUrl: String = "",
    val favicon: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val lastAccessed: Long = System.currentTimeMillis(),
    val position: Int = 0,
    val isIncognito: Boolean = false,
    val isPinned: Boolean = false,
    val isClosed: Boolean = false,
    val parentTabId: Long? = null,
    val sessionId: String = UUID.randomUUID().toString(),
    val scrollX: Int = 0,
    val scrollY: Int = 0,
    val zoomLevel: Float = 1.0f,
    val restoreState: String? = null,
    val thumbnailPath: String? = null,
    val metadata: Map<String, String> = emptyMap()
) : Parcelable {
    @Ignore var thumbnail: Bitmap? = null
    @Ignore var isSelected: Boolean = false
    @Ignore var isLoading: Boolean = false
    @Ignore var progress: Int = 0
    fun isValid(): Boolean = url.isNotBlank() && !isClosed
    fun isHomeTab(): Boolean = url.isEmpty() || url == "about:blank" || url == "about:home"
    fun getDomain(): String {
        return try { java.net.URI(url).host ?: "" } catch (e: Exception) { "" }
    }
    // convenience copy helpers omitted for brevity (they exist in previous version)
}