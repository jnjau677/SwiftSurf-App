package com.veestore.swiftsurf.features.reading

import android.webkit.WebView
import com.google.gson.Gson

class ReadingModeExtractor {

    private val gson = Gson()

    fun extractReadableContent(webView: WebView, callback: (ReadingContent?) -> Unit) {
        val extractionScript = """
            (function() {
                var article = document.querySelector('article');
                if (!article) {
                    article = document.querySelector('main');
                }
                if (!article) {
                    article = document.body;
                }
                
                return JSON.stringify({
                    title: document.title,
                    content: article.innerHTML,
                    textContent: article.textContent || '',
                    length: (article.textContent || '').length,
                    excerpt: ((article.textContent || '').substring(0, 200) + '...')
                });
            })();
        """.trimIndent()

        webView.evaluateJavascript(extractionScript) { result ->
            if (result != null && result != "null") {
                try {
                    // result comes as a quoted JSON string from evaluateJavascript; strip quotes if present
                    val json = if (result.startsWith("\"") && result.endsWith("\"")) {
                        // unescape inner JSON
                        gson.fromJson(result, String::class.java)
                    } else result
                    callback(parseReadingContent(json))
                } catch (e: Exception) {
                    callback(null)
                }
            } else {
                callback(null)
            }
        }
    }

    private fun parseReadingContent(json: String): ReadingContent {
        return gson.fromJson(json, ReadingContent::class.java)
    }

    data class ReadingContent(
        val title: String = "",
        val content: String = "",
        val textContent: String = "",
        val length: Int = 0,
        val excerpt: String = ""
    )
}