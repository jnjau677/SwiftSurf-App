package com.veestore.swiftsurf.ui.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import dagger.hilt.android.AndroidEntryPoint
import com.veestore.swiftsurf.R

@AndroidEntryPoint
class UserAgentSettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_agent_settings)

        supportFragmentManager.beginTransaction()
            .replace(R.id.ua_settings_container, com.veestore.swiftsurf.ui.fragments.UserAgentSettingsFragment())
            .commit()
    }
}