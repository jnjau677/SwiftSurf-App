package com.veestore.swiftsurf.data.remote.api

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

interface SearchApi {

    @GET("complete/search")
    suspend fun getGoogleSuggestions(
        @Query("q") query: String,
        @Query("client") client: String = "chrome",
        @Query("hl") language: String = "en",
        @Query("ds") disableShorthand: String = "cse"
    ): Response<Array<Array<Any>>>

    @GET("ac")
    @Headers("Accept: application/json")
    suspend fun getDuckDuckGoSuggestions(
        @Query("q") query: String,
        @Query("type") type: String = "list",
        @Query("kl") language: String = "wt-wt"
    ): Response<SearchSuggestionResponse>

    @GET("AS/Suggestions")
    suspend fun getBingSuggestions(
        @Query("qry") query: String,
        @Query("mkt") market: String = "en-US",
        @Query("cvid") clientId: String = "client"
    ): Response<String>

    @GET("w/api.php")
    suspend fun getWikipediaSuggestions(
        @Query("action") action: String = "opensearch",
        @Query("search") query: String,
        @Query("limit") limit: Int = 10,
        @Query("namespace") namespace: Int = 0,
        @Query("format") format: String = "json"
    ): Response<Array<Any>>

    @GET("suggest")
    suspend fun getCustomSuggestions(
        @Query("q") query: String,
        @Query("engine") engine: String,
        @Query("max") maxResults: Int = 10
    ): Response<List<SearchSuggestion>>

    @GET("search")
    suspend fun search(
        @Query("q") query: String,
        @Query("engine") engine: String = "google",
        @Query("page") page: Int = 1,
        @Query("count") count: Int = 10,
        @Query("safe") safeSearch: Boolean = true
    ): Response<SearchResults>
}

data class SearchSuggestionResponse(val phrase: String, val suggestions: List<SearchSuggestion>)
data class SearchSuggestion(
    val text: String,
    val description: String? = null,
    val url: String? = null,
    val type: SuggestionType = SuggestionType.SEARCH,
    val icon: String? = null,
    val isHistory: Boolean = false,
    val timestamp: Long? = null
)
enum class SuggestionType { SEARCH, HISTORY, BOOKMARK, URL, QUICK_ACTION }

data class SearchResults(
    val query: String,
    val totalResults: Long,
    val results: List<SearchResult>,
    val suggestions: List<String> = emptyList(),
    val relatedSearches: List<String> = emptyList(),
    val searchTime: Double = 0.0
)

data class SearchResult(
    val title: String,
    val url: String,
    val description: String? = null,
    val displayUrl: String = "",
    val favicon: String? = null,
    val thumbnail: String? = null,
    val snippet: String? = null,
    val date: String? = null,
    val isAds: Boolean = false,
    val isFeatured: Boolean = false
)