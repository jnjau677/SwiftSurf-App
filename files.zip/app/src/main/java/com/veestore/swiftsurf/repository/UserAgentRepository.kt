package com.veestore.swiftsurf.repository

import android.content.Context
import com.veestore.swiftsurf.data.local.datastore.SettingsDataStore
import com.veestore.swiftsurf.utils.UserAgentManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserAgentRepository @Inject constructor(
    private val context: Context,
    private val settingsDataStore: SettingsDataStore
) {

    /**
     * Emits the currently active user agent string:
     * - If a custom UA is set -> custom UA
     * - Else -> desktop UA at saved index (or fallback to default list)
     */
    val currentUserAgent: Flow<String> = combine(
        settingsDataStore.customUserAgent,
        settingsDataStore.userAgentIndex
    ) { customUa, index ->
        if (!customUa.isNullOrBlank()) return@combine customUa
        val list = UserAgentManager.getAvailableUserAgents(context)
        if (list.isEmpty()) UserAgentManager.getRandomDesktopUserAgent(context)
        else list.getOrElse(index.coerceAtLeast(0)) { list.first() }
    }

    fun getAvailableUserAgents(): List<String> = UserAgentManager.getAvailableUserAgents(context)

    suspend fun setCustomUserAgent(ua: String?) = settingsDataStore.setCustomUserAgent(ua)
    suspend fun setUserAgentIndex(index: Int) = settingsDataStore.setUserAgentIndex(index)
}