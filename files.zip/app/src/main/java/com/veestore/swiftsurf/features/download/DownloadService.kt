package com.veestore.swiftsurf.features.download

import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.annotation.Nullable

/**
 * Minimal foreground service stub for handling long-running downloads.
 * Expand this to enqueue downloads and show notifications.
 */
class DownloadService : Service() {

    override fun onCreate() {
        super.onCreate()
        // TODO: startForeground with notification if doing long-running work
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // TODO: handle download start/cancel actions from intents
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
    }
}