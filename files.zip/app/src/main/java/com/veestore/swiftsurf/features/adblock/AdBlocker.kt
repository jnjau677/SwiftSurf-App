package com.veestore.swiftsurf.features.adblock

import android.content.Context

class AdBlocker(context: Context) {

    private val adDomains = HashSet<String>()

    init {
        loadAdDomains()
    }

    private fun loadAdDomains() {
        adDomains.addAll(listOf(
            "doubleclick.net",
            "googleadservices.com",
            "googlesyndication.com",
            "google-analytics.com",
            "adsystem.com",
            "adnxs.com",
            "amazon-adsystem.com",
            "scorecardresearch.com",
            "2mdn.net",
            "facebook.com/tr"
        ))
    }

    fun isAd(url: String): Boolean {
        if (url.isBlank()) return false
        return adDomains.any { domain -> url.contains(domain, ignoreCase = true) }
    }

    fun addAdDomain(domain: String) { adDomains.add(domain) }
    fun removeAdDomain(domain: String) { adDomains.remove(domain) }
}