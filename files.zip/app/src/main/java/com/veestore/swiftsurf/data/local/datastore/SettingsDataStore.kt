package com.veestore.swiftsurf.data.local.datastore

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsDataStore @Inject constructor(
    private val dataStore: DataStore<Preferences>
) {

    companion object {
        private val KEY_THEME = intPreferencesKey("theme")
        private val KEY_DESKTOP_MODE = booleanPreferencesKey("desktop_mode")
        private val KEY_AD_BLOCK = booleanPreferencesKey("ad_block")
        private val KEY_JAVASCRIPT = booleanPreferencesKey("javascript")
        private val KEY_HOME_PAGE = stringPreferencesKey("home_page")
        private val KEY_SEARCH_ENGINE = stringPreferencesKey("search_engine")
        private val KEY_DOWNLOAD_LOCATION = stringPreferencesKey("download_location")
        private val KEY_PRIVATE_MODE = booleanPreferencesKey("private_mode")

        // User agent preferences
        private val KEY_USER_AGENT_INDEX = intPreferencesKey("user_agent_index")
        private val KEY_CUSTOM_USER_AGENT = stringPreferencesKey("custom_user_agent")
    }

    val currentTheme: Flow<Int> = dataStore.data.map { it[KEY_THEME] ?: 2 }
    val desktopModeEnabled: Flow<Boolean> = dataStore.data.map { it[KEY_DESKTOP_MODE] ?: false }
    val adBlockEnabled: Flow<Boolean> = dataStore.data.map { it[KEY_AD_BLOCK] ?: true }
    val javaScriptEnabled: Flow<Boolean> = dataStore.data.map { it[KEY_JAVASCRIPT] ?: true }
    val homePage: Flow<String> = dataStore.data.map { it[KEY_HOME_PAGE] ?: "https://www.google.com" }
    val searchEngine: Flow<String> = dataStore.data.map { it[KEY_SEARCH_ENGINE] ?: "google" }

    // User agent flows
    val userAgentIndex: Flow<Int> = dataStore.data.map { it[KEY_USER_AGENT_INDEX] ?: 0 }
    val customUserAgent: Flow<String?> = dataStore.data.map { it[KEY_CUSTOM_USER_AGENT] }

    suspend fun setTheme(theme: Int) = dataStore.edit { it[KEY_THEME] = theme }
    suspend fun setDesktopMode(enabled: Boolean) = dataStore.edit { it[KEY_DESKTOP_MODE] = enabled }
    suspend fun setAdBlockEnabled(enabled: Boolean) = dataStore.edit { it[KEY_AD_BLOCK] = enabled }
    suspend fun setJavaScriptEnabled(enabled: Boolean) = dataStore.edit { it[KEY_JAVASCRIPT] = enabled }
    suspend fun setHomePage(url: String) = dataStore.edit { it[KEY_HOME_PAGE] = url }
    suspend fun setSearchEngine(engine: String) = dataStore.edit { it[KEY_SEARCH_ENGINE] = engine }

    // User agent helpers
    suspend fun setUserAgentIndex(index: Int) = dataStore.edit { it[KEY_USER_AGENT_INDEX] = index }
    suspend fun setCustomUserAgent(ua: String?) = dataStore.edit { it[KEY_CUSTOM_USER_AGENT] = ua }
    suspend fun clearAll() = dataStore.edit { it.clear() }
}