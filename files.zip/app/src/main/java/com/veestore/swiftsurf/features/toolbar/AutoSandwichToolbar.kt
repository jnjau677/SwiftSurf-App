package com.veestore.swiftsurf.features.toolbar

import android.app.Activity
import android.view.View
import android.webkit.WebView
import kotlinx.coroutines.*

class AutoSandwichToolbar(
    private val toolbar: View,
    private val bottomBar: View,
    private val webView: WebView,
    private val activity: Activity
) {

    private val coroutineScope = CoroutineScope(Dispatchers.Main.immediate)
    private var hideJob: Job? = null

    init {
        setupScrollListener()
    }

    private fun setupScrollListener() {
        // If your AdvancedWebView has a scroll callback, call showToolbars/hideToolbars accordingly.
        // Example pseudo-code: webView.setOnScrollChangeListener { _, _, scrollY, _, oldScrollY -> ... }
    }

    fun showToolbars() {
        toolbar.animate().alpha(1f).translationY(0f).setDuration(180).start()
        bottomBar.animate().alpha(1f).translationY(0f).setDuration(180).start()
        scheduleAutoHide()
    }

    fun hideToolbars() {
        toolbar.animate().alpha(0f).translationY(-toolbar.height.toFloat()).setDuration(180).start()
        bottomBar.animate().alpha(0f).translationY(bottomBar.height.toFloat()).setDuration(180).start()
        hideJob?.cancel()
    }

    private fun scheduleAutoHide(delayMs: Long = 3000L) {
        hideJob?.cancel()
        hideJob = coroutineScope.launch {
            delay(delayMs)
            hideToolbars()
        }
    }

    fun resume() {
        showToolbars()
    }

    fun pause() {
        hideJob?.cancel()
    }
}