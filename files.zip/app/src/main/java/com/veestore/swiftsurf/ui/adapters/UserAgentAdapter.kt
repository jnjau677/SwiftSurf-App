package com.veestore.swiftsurf.ui.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.veestore.swiftsurf.databinding.ItemUserAgentBinding

class UserAgentAdapter(
    private val onClick: (String, Int) -> Unit
) : ListAdapter<String, UserAgentAdapter.VH>(DIFF) {

    private var selectedUa: String? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemUserAgentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val ua = getItem(position)
        holder.bind(ua, position)
    }

    fun setSelectedUserAgent(ua: String?) {
        val old = selectedUa
        selectedUa = ua
        // refresh an efficient way: call notifyDataSetChanged() for simplicity
        if (old != selectedUa) notifyDataSetChanged()
    }

    inner class VH(private val binding: ItemUserAgentBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(ua: String, pos: Int) {
            binding.txtUa.text = ua
            binding.radioSelected.isChecked = ua == selectedUa
            binding.root.setOnClickListener {
                selectedUa = ua
                notifyDataSetChanged()
                onClick(ua, pos)
            }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<String>() {
            override fun areItemsTheSame(oldItem: String, newItem: String) = oldItem == newItem
            override fun areContentsTheSame(oldItem: String, newItem: String) = oldItem == newItem
        }
    }
}