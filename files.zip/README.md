# via-advanced-browser

Starter Android project skeleton for the Via Advanced Browser app.

To run:
1. Install Android SDK and Java 17.
2. Generate gradle wrapper if you didn't add it: `gradle wrapper`.
3. Open the project in Android Studio or run `./gradlew assembleDebug`.

This repository contains:
- Room database skeleton
- Retrofit Search API
- Koin DI modules
- DataStore for settings
- Several feature stubs (vpn, adblock, reading mode, download manager)